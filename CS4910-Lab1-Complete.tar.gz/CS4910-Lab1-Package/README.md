# CS 4910: Introduction to Computer Security - Lab 1

## Security Fundamentals and AWS Environment Setup

**University of Colorado Colorado Springs**  
**Fall 2025 Semester**  
**Instructor: Rhett Saunders**

---

## 📋 Overview

This repository contains the complete Lab Assignment 1 for CS4910: Introduction to Computer Security. The lab combines theoretical security concepts with practical hands-on experience using AWS cloud infrastructure and security analysis tools.

## 🎯 Learning Objectives

Students will:
- Set up and configure a secure AWS EC2 environment
- Apply the CIA Triad to real-world security scenarios
- Analyze actual security incidents using established frameworks
- Explore cryptographic hash functions and collision resistance
- Examine digital certificates and public key infrastructure
- Develop practical security analysis skills

## 📁 Repository Structure

```
CS4910-Lab1/
├── CS4910_Lab1_Security_Fundamentals.md    # Main lab assignment
├── CS4910_Lab1_Instructor_Guide.md         # Comprehensive instructor guide
├── CS4910_Lab1_Report_Template.md          # Student report template
├── scripts/                                # Analysis tools and scripts
│   ├── aws_setup.sh                       # AWS environment setup script
│   ├── cia_analysis.py                    # CIA Triad analysis tool
│   ├── incident_analysis.py               # Security incident analysis tool
│   ├── hash_analysis.py                   # Hash function analysis tool
│   └── certificate_analysis.sh            # SSL/TLS certificate analysis tool
└── README.md                              # This file
```

## 🚀 Quick Start

### For Students

1. **Read the Lab Assignment**: Start with `CS4910_Lab1_Security_Fundamentals.md`
2. **Set up AWS Environment**: Follow Part 1 of the lab assignment
3. **Run Setup Script**: Execute `scripts/aws_setup.sh` on your EC2 instance
4. **Complete Analysis**: Use the provided scripts for each part of the lab
5. **Write Report**: Use `CS4910_Lab1_Report_Template.md` as your starting point

### For Instructors

1. **Review Instructor Guide**: Read `CS4910_Lab1_Instructor_Guide.md` thoroughly
2. **Prepare AWS Accounts**: Ensure students have access to AWS Educate credits
3. **Test Scripts**: Verify all analysis scripts work in your environment
4. **Customize as Needed**: Adapt the lab for your specific class requirements

## 🛠️ Technical Requirements

### AWS Infrastructure
- **Instance Type**: t3.micro (free tier eligible)
- **Operating System**: Ubuntu 22.04 LTS
- **Security Groups**: SSH (22), HTTP (80), HTTPS (443)
- **Network**: Public subnet with internet gateway access

### Software Dependencies
- Python 3.8+
- OpenSSL
- Required Python packages: `requests`, `cryptography`, `beautifulsoup4`
- Standard Linux utilities: `curl`, `wget`, `git`

## 📊 Lab Components

### Part 1: AWS Environment Setup (20 points)
- EC2 instance configuration
- Security group setup
- SSH key management
- Tool installation and verification

### Part 2: CIA Triad Analysis (25 points)
- Analysis of 5 security scenarios
- Application of Confidentiality, Integrity, Availability concepts
- Use of automated analysis script
- Critical thinking about security trade-offs

### Part 3: Security Incident Analysis (20 points)
- Research of recent security incident
- Application of security framework
- Analysis of affected security properties
- Written analysis and documentation

### Part 4: Hash Function Investigation (25 points)
- Theoretical understanding of collision resistance
- Practical demonstration of hash properties
- Birthday attack simulation
- Mathematical concept application

### Part 5: Public-Key Certificate Analysis (10 points)
- SSL/TLS certificate examination
- Digital signature verification
- Certificate chain analysis
- PKI concept application

## 🔧 Script Descriptions

### `aws_setup.sh`
Automated setup script for AWS EC2 instances that:
- Updates system packages
- Installs required tools and dependencies
- Creates lab directory structure
- Configures security settings
- Verifies installation

### `cia_analysis.py`
Interactive tool for CIA Triad analysis that:
- Guides students through scenario analysis
- Calculates risk scores and priorities
- Generates comprehensive reports
- Provides educational framework

### `incident_analysis.py`
Security incident analysis framework that:
- Structures incident research
- Applies security property analysis
- Generates professional reports
- Provides analytical insights

### `hash_analysis.py`
Comprehensive hash function analysis tool that:
- Demonstrates avalanche effect
- Simulates birthday attacks
- Compares hash algorithms
- Explains theoretical concepts

### `certificate_analysis.sh`
SSL/TLS certificate analysis tool that:
- Retrieves certificates from servers
- Extracts key information
- Analyzes certificate chains
- Performs security assessment

## 📈 Assessment and Grading

The lab uses a comprehensive rubric evaluating:
- **Technical Implementation** (40%): AWS setup, script execution, tool usage
- **Conceptual Understanding** (35%): Security concept application, analysis quality
- **Documentation and Communication** (25%): Report quality, screenshots, explanations

See the Instructor Guide for detailed grading rubrics and assessment guidelines.

## 🔒 Security Considerations

This lab emphasizes security best practices:
- Proper AWS security group configuration
- SSH key management and permissions
- Principle of least privilege
- Secure communication protocols
- Data protection and privacy

## 🆘 Troubleshooting

### Common Issues

**AWS Connection Problems**
- Verify security group allows SSH from your IP
- Check SSH key permissions (`chmod 400 keyfile.pem`)
- Ensure instance is running and accessible

**Script Execution Issues**
- Verify Python 3.8+ is installed
- Install missing dependencies with `pip3 install`
- Check file permissions for shell scripts

**Certificate Analysis Failures**
- Test network connectivity to target domains
- Verify OpenSSL installation
- Try alternative domains if target is unavailable

## 📚 Educational Resources

### Required Reading
- Lab assignment document
- Instructor-provided security frameworks
- AWS documentation for EC2 setup

### Supplementary Materials
- [NIST Cybersecurity Framework](https://www.nist.gov/cyberframework)
- [RFC 5280 - Internet X.509 PKI Certificate](https://tools.ietf.org/html/rfc5280)
- [OWASP Security Testing Guide](https://owasp.org/www-project-web-security-testing-guide/)

## 🤝 Contributing

This lab is designed for educational use. Instructors are welcome to:
- Adapt scripts for their specific environments
- Modify scenarios for current relevance
- Extend analysis tools with additional features
- Share improvements with the community

## 📄 License

This educational material is provided for academic use. Please respect academic integrity policies when using these materials.

## 📞 Support

For technical issues or questions:
- **Students**: Contact your instructor during office hours
- **Instructors**: Refer to the comprehensive Instructor Guide
- **Technical Issues**: Check the troubleshooting section above

## 🔄 Version History

- **v1.0** (July 2025): Initial release for Fall 2025 semester
- Comprehensive lab with AWS integration
- Full script suite and documentation
- Instructor guide and assessment rubrics

---

## 🎓 Academic Integrity

This lab is designed to be completed individually unless otherwise specified by your instructor. While you may discuss concepts with classmates, all submitted work must be your own. Sharing scripts, outputs, or written analysis constitutes academic dishonesty.

---

**Happy Learning! 🚀**

*CS4910: Introduction to Computer Security*  
*University of Colorado Colorado Springs*  
*Fall 2025*