# CS 4910: Introduction to Computer Security
## Lab Assignment 1 Report: Security Fundamentals and AWS Environment Setup
**Fall 2025 Semester**  
**University of Colorado Colorado Springs**  
**Instructor: Rhett Saunders**

---

**Student Name**: [Your Name]  
**Student ID**: [Your Student ID]  
**Date Submitted**: [Submission Date]  
**Lab Partner**: [If applicable, otherwise write "Individual Work"]

---

## Executive Summary

[Write a 2-3 paragraph summary of what you accomplished in this lab, key findings, and lessons learned. This should be written last but appear first in your report.]

---

## Part 1: AWS Environment Setup

### 1.1 Instance Configuration

**AWS Instance Details:**
- Instance ID: [Your instance ID]
- Instance Type: [e.g., t3.micro]
- AMI: [e.g., Ubuntu 22.04 LTS]
- Region: [e.g., us-east-1]
- Public IP: [Your instance public IP]

**Security Group Configuration:**
```
[Paste your security group rules here]
Inbound Rules:
- SSH (22): [Your IP]/32
- HTTP (80): 0.0.0.0/0
- HTTPS (443): 0.0.0.0/0

Outbound Rules:
- All traffic: 0.0.0.0/0
```

### 1.2 Connection Verification

**Screenshot 1.1**: SSH Connection Success
[Insert screenshot showing successful SSH connection to your EC2 instance, including the Ubuntu welcome message and your instance's IP address]

**Tools Verification:**
```bash
# Paste output of tool verification commands
python3 --version
openssl version
pip3 list | grep -E "(requests|cryptography)"
```

### 1.3 Security Considerations

[Discuss the security measures you implemented during AWS setup. Consider:]
- Key pair management and permissions
- Security group configuration rationale
- Network access restrictions
- Any additional security measures taken

---

## Part 2: CIA Triad Analysis

### 2.1 Methodology

[Explain how you approached the CIA Triad analysis, including use of the provided script]

### 2.2 Scenario Analyses

#### 2.2.1 Automated Teller Machine (ATM)

**CIA Ratings:**
- Confidentiality: [X]/5
- Integrity: [X]/5  
- Availability: [X]/5

**Justification:**
- **Confidentiality**: [Your detailed explanation of why you rated confidentiality at this level]
- **Integrity**: [Your detailed explanation of why you rated integrity at this level]
- **Availability**: [Your detailed explanation of why you rated availability at this level]

**Primary Security Concern**: [Which aspect is most critical and why]

#### 2.2.2 Domain Name System (DNS)

**CIA Ratings:**
- Confidentiality: [X]/5
- Integrity: [X]/5  
- Availability: [X]/5

**Justification:**
[Provide detailed justifications for each rating]

#### 2.2.3 Implanted Defibrillator

**CIA Ratings:**
- Confidentiality: [X]/5
- Integrity: [X]/5  
- Availability: [X]/5

**Justification:**
[Provide detailed justifications for each rating]

#### 2.2.4 Online Voting System

**CIA Ratings:**
- Confidentiality: [X]/5
- Integrity: [X]/5  
- Availability: [X]/5

**Justification:**
[Provide detailed justifications for each rating]

#### 2.2.5 Automated Metro Train System

**CIA Ratings:**
- Confidentiality: [X]/5
- Integrity: [X]/5  
- Availability: [X]/5

**Justification:**
[Provide detailed justifications for each rating]

### 2.3 Analysis Summary

**Screenshot 2.1**: CIA Analysis Script Output
[Insert screenshot of your CIA analysis script execution and results]

**Key Insights:**
[Summarize your key findings from the CIA analysis, including which scenarios had the highest security requirements and why]

---

## Part 3: Security Incident Analysis

### 3.1 Incident Selection

**Incident Title**: [Title of the security incident you researched]  
**Date**: [Date of the incident]  
**Source**: [URL of your news source]  
**Source Credibility**: [Brief assessment of why this is a credible source]

### 3.2 Incident Description

[Write 1-2 paragraphs describing the security incident. Include:]
- What happened?
- Who was affected?
- How was the attack carried out?
- What was the impact?

### 3.3 Security Framework Analysis

**Affected Security Properties:**
- [ ] Confidentiality - [Explain if/how this was affected]
- [ ] Integrity - [Explain if/how this was affected]
- [ ] Availability - [Explain if/how this was affected]
- [ ] Authenticity - [Explain if/how this was affected]
- [ ] Accountability - [Explain if/how this was affected]

**Impact Assessment**: [X]/5 - [Justify your impact rating]

**Attack Vector**: [Describe how the attack was carried out]

### 3.4 Analysis Discussion

[Write 1-2 paragraphs discussing the security implications of this incident. Consider:]
- Which security properties were most severely affected?
- What could have been done to prevent this incident?
- What lessons can be learned for future security practices?

**Screenshot 3.1**: Incident Analysis Script Output
[Insert screenshot of your incident analysis script execution]

---

## Part 4: Hash Function Investigation

### 4.1 Theoretical Analysis

#### 4.1.1 Collision Resistance Question

**Question**: Is it true that for all messages x, x' with x ≠ x', we have H(x) ≠ H(x')?

**Answer**: [Your answer - should be "No"]

**Explanation**: [Explain using the pigeonhole principle. Your explanation should cover:]
- The pigeonhole principle concept
- How it applies to hash functions
- Why collisions must exist mathematically
- The difference between mathematical existence and computational feasibility

#### 4.1.2 Collision Resistance Types

**Weak Collision Resistance (Second Preimage Resistance):**
[Define weak collision resistance and explain what it means]

**Strong Collision Resistance:**
[Define strong collision resistance and explain what it means]

**Key Differences:**
[Explain how weak and strong collision resistance differ, including computational requirements]

#### 4.1.3 Birthday Paradox

**Birthday Paradox Explanation:**
[Explain the birthday paradox concept and the mathematics behind it]

**Birthday Attack Against Hash Functions:**
[Explain how the birthday paradox applies to attacking hash functions]

#### 4.1.4 Attack Comparison

**Finding Alice's Specific Birthday vs. Any Matching Birthdays:**
[Compare the difficulty of these two scenarios]

**Relationship to Collision Resistance:**
[Explain how this relates to weak vs. strong collision resistance]

### 4.2 Practical Analysis

**Screenshot 4.1**: Avalanche Effect Demonstration
[Insert screenshot showing the avalanche effect analysis from your script]

**Screenshot 4.2**: Birthday Attack Simulation
[Insert screenshot showing the birthday attack simulation results]

**Screenshot 4.3**: Hash Algorithm Comparison
[Insert screenshot showing comparison of different hash algorithms]

### 4.3 Analysis Results

**Avalanche Effect Findings:**
[Summarize your findings about how small input changes affect hash outputs]

**Birthday Attack Results:**
[Discuss the results of your birthday attack simulation, including how actual results compared to theoretical expectations]

**Algorithm Comparison Insights:**
[Compare the different hash algorithms you tested]

---

## Part 5: Public-Key Certificate Analysis

### 5.1 Certificate Investigation

**Target Domain**: www.uccs.edu  
**Analysis Date**: [Date you performed the analysis]

#### 5.1.1 Certificate Objective

**Question**: What is the objective of the digital certificate?

**Answer**: [Explain the purpose of digital certificates, including authentication, encryption, integrity, and non-repudiation]

#### 5.1.2 Certificate Details

**SHA-1 Fingerprint**: [Insert the SHA-1 fingerprint you found]

**Certificate Authority**: [Name of the CA that issued the certificate]

**Certificate Subject**: [The subject/owner of the certificate]

**Screenshot 5.1**: Certificate Fingerprint and CA Information
[Insert screenshot showing the certificate fingerprint, CA, and subject information]

#### 5.1.3 Certificate Validity

**Issue Date (Not Before)**: [Certificate issue date]  
**Expiration Date (Not After)**: [Certificate expiration date]

**Screenshot 5.2**: Certificate Validity Dates
[Insert screenshot showing the certificate validity period]

**Question**: Does the UCCS website need to present this certificate every time a client accesses it?

**Answer**: [Explain when and how certificates are presented during TLS handshake]

#### 5.1.4 Methodology

**Tools Used**: [List the tools you used - OpenSSL, browser developer tools, etc.]

**Commands Executed**:
```bash
# List the specific commands you used
openssl s_client -connect www.uccs.edu:443 -servername www.uccs.edu
# Add other commands you used
```

**Process Steps**:
1. [Step 1 of your analysis process]
2. [Step 2 of your analysis process]
3. [Continue with all steps]

**Reproducibility**: [Explain how someone else could reproduce your analysis]

### 5.2 Additional Analysis

**Certificate Chain**: [Describe the certificate chain you observed]

**Security Assessment**: [Discuss any security observations about the certificate]

**Screenshot 5.3**: Complete Certificate Analysis Output
[Insert screenshot of your complete certificate analysis script output]

---

## Part 6: Lessons Learned and Reflection

### 6.1 Technical Skills Gained

[Discuss the technical skills you developed during this lab, such as:]
- AWS EC2 management
- Command-line security tools
- Certificate analysis
- Hash function analysis

### 6.2 Security Concepts Reinforced

[Discuss how this lab reinforced your understanding of security concepts:]
- CIA Triad application
- Real-world security incidents
- Cryptographic principles
- Public key infrastructure

### 6.3 Challenges Encountered

[Describe any challenges you faced and how you overcame them:]
- Technical difficulties
- Conceptual challenges
- Time management issues

### 6.4 Future Applications

[Discuss how you might apply what you learned in future coursework or career:]
- Security analysis skills
- Cloud computing experience
- Incident response knowledge

---

## Part 7: Conclusion

[Write a concluding paragraph that summarizes your overall experience with the lab and key takeaways]

---

## Appendix

### A.1 Script Outputs

[Include any additional script outputs that support your analysis]

### A.2 Configuration Files

[Include any configuration files or additional technical details]

### A.3 References

[List any additional sources you consulted beyond those provided in the lab assignment]

---

## Academic Integrity Statement

I certify that this work is my own and that I have not received unauthorized assistance from any person or source. All sources used have been properly cited.

**Signature**: [Your name]  
**Date**: [Date]

---

**Report Statistics:**
- Total Pages: [X]
- Word Count: [Approximate word count]
- Screenshots Included: [Number]
- Scripts Executed: [Number]