# CS 4910: Introduction to Computer Security
## Lab Assignment 1: Security Fundamentals and AWS Environment Setup
**Fall 2025 Semester**  
**University of Colorado Colorado Springs**  
**Instructor: Rhett Saunders**

---

## Lab Overview

This is the first of several lab assignments in CS 4910. In this lab, you will:
1. Set up a secure AWS virtual machine environment
2. Explore fundamental security concepts including the CIA Triad
3. Analyze real-world security incidents
4. Investigate cryptographic hash functions and their properties
5. Examine public-key certificates and digital signatures
6. Use automated scripts to validate your understanding

**Estimated Time:** 4-6 hours  
**Due Date:** [To be announced by instructor]

---

## Learning Objectives

By the end of this lab, you will be able to:
- Set up and configure a secure AWS EC2 instance for security research
- Apply the CIA Triad (Confidentiality, Integrity, Availability) to real-world systems
- Analyze security incidents using established security frameworks
- Understand hash function properties and collision resistance
- Examine and validate digital certificates
- Use command-line tools for security analysis

---

## Prerequisites

- Basic understanding of computer networks and operating systems
- AWS account with educational credits (provided by instructor)
- SSH client (PuTTY for Windows, Terminal for Mac/Linux)
- Web browser with developer tools

---

## Part 1: AWS Environment Setup (20 points)

### 1.1 Theory: Cloud Security Fundamentals

Before setting up your AWS environment, it's important to understand the shared responsibility model in cloud computing:

- **AWS Responsibility**: Physical security, infrastructure, hypervisor security
- **Your Responsibility**: Operating system security, application security, data encryption, network configuration

### 1.2 Setting Up Your AWS EC2 Instance

1. **Launch EC2 Instance**:
   - AMI: Ubuntu 22.04 LTS
   - Instance Type: t3.micro (free tier eligible)
   - Security Group: Create a new security group named "CS4910-Lab1-SG"
   - Key Pair: Create and download a new key pair named "CS4910-Lab1-Key"

2. **Security Group Configuration**:
   ```
   Inbound Rules:
   - SSH (22): Your IP only
   - HTTP (80): Anywhere (for web server testing)
   - HTTPS (443): Anywhere (for certificate analysis)
   
   Outbound Rules:
   - All traffic: Anywhere (default)
   ```

3. **Connect to Your Instance**:
   ```bash
   chmod 400 CS4910-Lab1-Key.pem
   ssh -i CS4910-Lab1-Key.pem ubuntu@[YOUR-INSTANCE-IP]
   ```

### 1.3 Install Required Tools

Run the setup script to install necessary tools:

```bash
#!/bin/bash
# CS4910 Lab 1 Setup Script
sudo apt update && sudo apt upgrade -y
sudo apt install -y curl wget openssl python3 python3-pip git vim
pip3 install requests beautifulsoup4 cryptography
```

**Deliverable 1.1**: Screenshot of successful SSH connection to your EC2 instance showing the Ubuntu welcome message and your instance's IP address.

---

## Part 2: CIA Triad Analysis (25 points)

### 2.1 Theory: The CIA Triad

The CIA Triad forms the foundation of information security:

- **Confidentiality**: Ensuring information is accessible only to authorized individuals
- **Integrity**: Maintaining accuracy and completeness of data
- **Availability**: Ensuring information and resources are accessible when needed

Additional concepts:
- **Authenticity**: Verifying the identity of users and data sources
- **Accountability**: Ensuring actions can be traced to responsible parties

### 2.2 Practical Analysis

For each scenario below, analyze the CIA requirements and use the provided script to validate your understanding.

Create and run the CIA analysis script:

```python
#!/usr/bin/env python3
# cia_analysis.py - CIA Triad Analysis Tool

import json
import sys

def analyze_scenario(scenario_name, confidentiality, integrity, availability, justification):
    """
    Analyze a scenario for CIA requirements
    
    Args:
        scenario_name: Name of the scenario
        confidentiality: Importance level (1-5, 5 being highest)
        integrity: Importance level (1-5, 5 being highest)  
        availability: Importance level (1-5, 5 being highest)
        justification: Dictionary with explanations for each rating
    """
    
    print(f"\n=== CIA Analysis: {scenario_name} ===")
    print(f"Confidentiality: {confidentiality}/5 - {justification['confidentiality']}")
    print(f"Integrity: {integrity}/5 - {justification['integrity']}")
    print(f"Availability: {availability}/5 - {justification['availability']}")
    
    # Calculate risk score
    total_score = confidentiality + integrity + availability
    risk_level = "Low" if total_score <= 8 else "Medium" if total_score <= 12 else "High"
    print(f"Overall Risk Level: {risk_level} (Score: {total_score}/15)")
    
    return {
        'scenario': scenario_name,
        'scores': {
            'confidentiality': confidentiality,
            'integrity': integrity,
            'availability': availability
        },
        'justification': justification,
        'risk_level': risk_level
    }

# Example usage and template
if __name__ == "__main__":
    # Template for student analysis
    scenarios = [
        "ATM System",
        "DNS System", 
        "Implanted Defibrillator",
        "Online Voting System",
        "Automated Metro Train"
    ]
    
    print("CS4910 Lab 1 - CIA Triad Analysis Tool")
    print("Complete your analysis for each scenario:")
    
    for scenario in scenarios:
        print(f"\n--- Analyze: {scenario} ---")
        print("Rate each aspect from 1-5 (5 = highest importance)")
        # Students will modify this section with their analysis
```

### 2.3 Scenario Analysis

**Complete the following analyses using the script above:**

a. **Automated Teller Machine (ATM)**
b. **Domain Name System (DNS)**
c. **Implanted Defibrillator**
d. **Online Voting System**
e. **Automated Metro Train System**

**Deliverable 2.1**: For each scenario, provide:
- CIA importance ratings (1-5 scale)
- Detailed justification for each rating
- Screenshot of script output
- Discussion of which aspect is most critical and why

---

## Part 3: Security Incident Analysis (20 points)

### 3.1 Theory: Security Incident Framework

When analyzing security incidents, consider:
- **Attack Vector**: How the attack was carried out
- **Impact Assessment**: Which security properties were violated
- **Root Cause**: Underlying vulnerabilities that enabled the attack
- **Mitigation**: Steps taken to address the incident

### 3.2 Incident Research and Analysis

Use the provided script to structure your incident analysis:

```python
#!/usr/bin/env python3
# incident_analysis.py - Security Incident Analysis Tool

import requests
import json
from datetime import datetime

class SecurityIncidentAnalyzer:
    def __init__(self):
        self.incident_data = {}
    
    def analyze_incident(self, title, date, description, affected_properties, impact_level):
        """
        Analyze a security incident
        
        Args:
            title: Incident title
            date: Date of incident
            description: Brief description
            affected_properties: List of affected security properties
            impact_level: Scale 1-5 (5 = highest impact)
        """
        
        self.incident_data = {
            'title': title,
            'date': date,
            'description': description,
            'affected_properties': affected_properties,
            'impact_level': impact_level,
            'analysis_date': datetime.now().isoformat()
        }
        
        print(f"\n=== Security Incident Analysis ===")
        print(f"Incident: {title}")
        print(f"Date: {date}")
        print(f"Impact Level: {impact_level}/5")
        print(f"\nDescription: {description}")
        print(f"\nAffected Security Properties:")
        
        for prop in affected_properties:
            print(f"  - {prop}")
        
        return self.incident_data
    
    def generate_report(self):
        """Generate a formatted analysis report"""
        if not self.incident_data:
            print("No incident data to report")
            return
            
        print(f"\n=== INCIDENT ANALYSIS REPORT ===")
        print(f"Generated: {self.incident_data['analysis_date']}")
        print(f"Incident: {self.incident_data['title']}")
        print(f"Overall Impact: {self.incident_data['impact_level']}/5")
        
        # Calculate affected property percentages
        total_properties = 5  # CIA + Authenticity + Accountability
        affected_count = len(self.incident_data['affected_properties'])
        coverage = (affected_count / total_properties) * 100
        
        print(f"Security Property Coverage: {coverage:.1f}% ({affected_count}/{total_properties})")

# Example usage
if __name__ == "__main__":
    analyzer = SecurityIncidentAnalyzer()
    
    print("CS4910 Lab 1 - Security Incident Analysis Tool")
    print("Research a recent security incident and analyze it using this framework")
```

### 3.3 Assignment Requirements

1. **Research**: Find a recent security incident (within the last 2 years) from a reputable news source
2. **Analysis**: Use the script to analyze which security properties were affected
3. **Report**: Write 2-3 paragraphs explaining the incident and its security implications

**Deliverable 3.1**: 
- Link to news source
- Completed incident analysis using the script
- Written analysis (2-3 paragraphs) explaining the incident and affected security properties
- Screenshot of script output

---

## Part 4: Hash Function Investigation (25 points)

### 4.1 Theory: Cryptographic Hash Functions

Hash functions are fundamental to modern cryptography. Key properties include:

- **Deterministic**: Same input always produces same output
- **Fixed Output Size**: Regardless of input size
- **Avalanche Effect**: Small input changes cause large output changes
- **One-way Function**: Computationally infeasible to reverse

**Collision Resistance Types**:
- **Weak Collision Resistance (Second Preimage Resistance)**: Given x, hard to find x' where H(x) = H(x')
- **Strong Collision Resistance**: Hard to find any x, x' where H(x) = H(x')

### 4.2 Hash Function Analysis Script

```python
#!/usr/bin/env python3
# hash_analysis.py - Hash Function Analysis Tool

import hashlib
import random
import string
import time
from collections import defaultdict

class HashAnalyzer:
    def __init__(self):
        self.algorithms = ['md5', 'sha1', 'sha256', 'sha512']
    
    def hash_string(self, data, algorithm='sha256'):
        """Hash a string using specified algorithm"""
        hasher = hashlib.new(algorithm)
        hasher.update(data.encode('utf-8'))
        return hasher.hexdigest()
    
    def demonstrate_avalanche_effect(self, base_string="Hello World"):
        """Demonstrate how small changes affect hash output"""
        print(f"\n=== Avalanche Effect Demonstration ===")
        print(f"Base string: '{base_string}'")
        
        base_hash = self.hash_string(base_string)
        print(f"SHA256 Hash: {base_hash}")
        
        # Small modifications
        modifications = [
            base_string + "!",  # Add character
            base_string.replace("H", "h"),  # Change case
            base_string.replace(" ", "_"),  # Replace character
            base_string[:-1]  # Remove character
        ]
        
        for i, modified in enumerate(modifications):
            mod_hash = self.hash_string(modified)
            print(f"\nModification {i+1}: '{modified}'")
            print(f"SHA256 Hash: {mod_hash}")
            
            # Calculate bit differences
            diff_bits = bin(int(base_hash, 16) ^ int(mod_hash, 16)).count('1')
            total_bits = len(base_hash) * 4  # Each hex digit = 4 bits
            diff_percentage = (diff_bits / total_bits) * 100
            
            print(f"Bit differences: {diff_bits}/{total_bits} ({diff_percentage:.1f}%)")
    
    def birthday_attack_simulation(self, hash_bits=16):
        """Simulate birthday attack on truncated hash"""
        print(f"\n=== Birthday Attack Simulation ===")
        print(f"Using {hash_bits}-bit truncated SHA256")
        
        hash_map = {}
        attempts = 0
        max_attempts = 2 ** (hash_bits + 2)  # Reasonable upper limit
        
        start_time = time.time()
        
        while attempts < max_attempts:
            # Generate random string
            random_string = ''.join(random.choices(string.ascii_letters + string.digits, k=10))
            
            # Get truncated hash
            full_hash = self.hash_string(random_string)
            truncated_hash = full_hash[:hash_bits//4]  # Convert bits to hex digits
            
            if truncated_hash in hash_map:
                end_time = time.time()
                print(f"Collision found after {attempts} attempts!")
                print(f"String 1: '{hash_map[truncated_hash]}'")
                print(f"String 2: '{random_string}'")
                print(f"Truncated hash: {truncated_hash}")
                print(f"Time taken: {end_time - start_time:.2f} seconds")
                
                # Theoretical vs actual
                theoretical = 2 ** (hash_bits / 2)
                print(f"Theoretical attempts needed: ~{theoretical:.0f}")
                print(f"Actual attempts: {attempts}")
                return attempts
            
            hash_map[truncated_hash] = random_string
            attempts += 1
            
            if attempts % 1000 == 0:
                print(f"Attempts: {attempts}")
        
        print(f"No collision found after {attempts} attempts")
        return attempts

    def compare_algorithms(self, test_string="CS4910 Security Lab"):
        """Compare different hash algorithms"""
        print(f"\n=== Hash Algorithm Comparison ===")
        print(f"Input: '{test_string}'")
        
        for algo in self.algorithms:
            try:
                hash_value = self.hash_string(test_string, algo)
                print(f"{algo.upper()}: {hash_value}")
            except ValueError:
                print(f"{algo.upper()}: Not available")

# Example usage
if __name__ == "__main__":
    analyzer = HashAnalyzer()
    
    print("CS4910 Lab 1 - Hash Function Analysis")
    
    # Run demonstrations
    analyzer.demonstrate_avalanche_effect()
    analyzer.compare_algorithms()
    analyzer.birthday_attack_simulation(16)  # 16-bit for quick demo
```

### 4.3 Theoretical Questions

Answer the following questions and use the script to support your explanations:

a. **Collision Resistance**: Is it true that for all messages x, x' with x ≠ x', we have H(x) ≠ H(x')? Explain using the pigeonhole principle.

b. **Resistance Types**: Define and differentiate weak vs. strong collision resistance.

c. **Birthday Paradox**: Explain the birthday paradox and how it applies to hash function attacks.

d. **Attack Comparison**: Compare the difficulty of finding someone with Alice's birthday vs. finding any two people with the same birthday.

**Deliverable 4.1**:
- Answers to theoretical questions (a-d)
- Screenshots of script output for avalanche effect demonstration
- Results from birthday attack simulation
- Analysis of hash algorithm comparison

---

## Part 5: Public-Key Certificate Analysis (10 points)

### 5.1 Theory: Digital Certificates and PKI

Public Key Infrastructure (PKI) enables secure communication through:
- **Digital Certificates**: Bind public keys to identities
- **Certificate Authorities (CA)**: Trusted third parties that issue certificates
- **Certificate Chain**: Hierarchy of trust from root CA to end-entity certificates

### 5.2 Certificate Analysis Script

```bash
#!/bin/bash
# certificate_analysis.sh - SSL/TLS Certificate Analysis Tool

DOMAIN="www.uccs.edu"
PORT="443"

echo "=== CS4910 Lab 1 - Certificate Analysis ==="
echo "Analyzing certificate for: $DOMAIN"

# Get certificate information
echo -e "\n=== Certificate Details ==="
openssl s_client -connect $DOMAIN:$PORT -servername $DOMAIN </dev/null 2>/dev/null | \
openssl x509 -noout -text

# Get certificate fingerprints
echo -e "\n=== Certificate Fingerprints ==="
CERT=$(openssl s_client -connect $DOMAIN:$PORT -servername $DOMAIN </dev/null 2>/dev/null | \
openssl x509)

echo "SHA-1 Fingerprint:"
echo "$CERT" | openssl x509 -noout -fingerprint -sha1

echo "SHA-256 Fingerprint:"
echo "$CERT" | openssl x509 -noout -fingerprint -sha256

# Get certificate dates
echo -e "\n=== Certificate Validity ==="
echo "$CERT" | openssl x509 -noout -dates

# Get certificate subject and issuer
echo -e "\n=== Certificate Identity ==="
echo "Subject:"
echo "$CERT" | openssl x509 -noout -subject

echo "Issuer:"
echo "$CERT" | openssl x509 -noout -issuer

# Certificate chain
echo -e "\n=== Certificate Chain ==="
openssl s_client -connect $DOMAIN:$PORT -servername $DOMAIN -showcerts </dev/null 2>/dev/null | \
grep -E "(subject=|issuer=)"
```

### 5.3 Certificate Investigation

Use the script above to analyze the UCCS website certificate and answer:

a. **Objective**: What is the purpose of the digital certificate?
b. **Fingerprint**: Find the SHA-1 fingerprint and identify the issuing CA
c. **Validity**: When was the certificate issued and when does it expire?
d. **Methodology**: Explain your analysis process and tools used

**Deliverable 5.1**:
- Screenshots of certificate analysis output
- Answers to questions (a-d)
- Discussion of certificate chain validation

---

## Submission Requirements

### File Structure
Create the following directory structure on your AWS instance:

```
~/CS4910-Lab1/
├── scripts/
│   ├── cia_analysis.py
│   ├── incident_analysis.py
│   ├── hash_analysis.py
│   └── certificate_analysis.sh
├── outputs/
│   ├── cia_results.txt
│   ├── incident_report.txt
│   ├── hash_analysis.txt
│   └── certificate_analysis.txt
├── screenshots/
│   ├── aws_connection.png
│   ├── cia_analysis.png
│   ├── incident_analysis.png
│   ├── hash_demo.png
│   └── certificate_analysis.png
└── lab_report.md
```

### Submission Checklist

- [ ] AWS EC2 instance properly configured and accessible
- [ ] All scripts executed successfully with output saved
- [ ] Screenshots captured for each major section
- [ ] Written analysis completed for all theoretical questions
- [ ] Security incident research and analysis completed
- [ ] Certificate analysis completed with proper documentation
- [ ] All files organized in required directory structure
- [ ] Lab report summarizing findings and lessons learned

### Grading Rubric

| Component | Points | Criteria |
|-----------|--------|----------|
| AWS Setup | 20 | Instance configured correctly, security groups properly set, connection established |
| CIA Analysis | 25 | All scenarios analyzed with proper justification, script used effectively |
| Incident Analysis | 20 | Recent incident researched, proper analysis framework applied, clear writing |
| Hash Functions | 25 | Theoretical questions answered correctly, script demonstrations completed |
| Certificates | 10 | Certificate analysis completed, tools used properly, findings documented |
| **Total** | **100** | |

### Late Submission Policy
- 10% deduction per day late
- No submissions accepted after 1 week past due date

---

## Additional Resources

- [AWS EC2 User Guide](https://docs.aws.amazon.com/ec2/)
- [OpenSSL Documentation](https://www.openssl.org/docs/)
- [NIST Cybersecurity Framework](https://www.nist.gov/cyberframework)
- [RFC 5280 - Internet X.509 PKI Certificate](https://tools.ietf.org/html/rfc5280)

---

## Academic Integrity

This is an individual assignment. While you may discuss concepts with classmates, all work submitted must be your own. Sharing scripts, outputs, or written analysis constitutes academic dishonesty.

---

**Questions?** Contact Instructor Rhett Saunders during office hours or via email.

*Last Updated: July 2025*