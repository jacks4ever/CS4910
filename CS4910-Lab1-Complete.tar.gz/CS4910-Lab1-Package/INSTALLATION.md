# CS4910 Lab 1 - Installation and Setup Guide

## Quick Start

### For Students
1. **Download and Extract**: Extract this package to your local machine
2. **AWS Setup**: Follow the main lab document to create your EC2 instance
3. **Upload Scripts**: Transfer the `scripts/` folder to your EC2 instance
4. **Run Setup**: Execute `./scripts/aws_setup.sh` on your EC2 instance
5. **Begin Lab**: Follow the lab assignment document step by step

### For Instructors
1. **Review Materials**: Read the Instructor Guide thoroughly
2. **Test Environment**: Set up a test EC2 instance and verify all scripts work
3. **Customize**: Modify any scripts or documents as needed for your class
4. **Distribute**: Provide students with the lab assignment and scripts

## File Transfer to AWS EC2

### Using SCP (Secure Copy)
```bash
# Transfer entire scripts folder
scp -i your-key.pem -r scripts/ ubuntu@your-ec2-ip:~/

# Transfer individual files
scp -i your-key.pem CS4910_Lab1_Security_Fundamentals.md ubuntu@your-ec2-ip:~/
```

### Using SFTP
```bash
sftp -i your-key.pem ubuntu@your-ec2-ip
put -r scripts/
put CS4910_Lab1_Security_Fundamentals.md
```

### Using Git (Alternative)
```bash
# On your EC2 instance
git clone [your-repository-url]
# or upload to GitHub/GitLab and clone
```

## Package Contents

- `CS4910_Lab1_Security_Fundamentals.md` - Main lab assignment
- `CS4910_Lab1_Instructor_Guide.md` - Comprehensive instructor guide  
- `CS4910_Lab1_Report_Template.md` - Student report template
- `README.md` - Overview and quick start guide
- `scripts/` - All analysis tools and setup scripts
  - `aws_setup.sh` - Automated environment setup
  - `cia_analysis.py` - CIA Triad analysis tool
  - `incident_analysis.py` - Security incident analysis
  - `hash_analysis.py` - Hash function analysis
  - `certificate_analysis.sh` - Certificate analysis tool

## Prerequisites

### AWS Account
- AWS Educate account with credits
- Ability to launch EC2 instances
- Basic familiarity with AWS console

### Local Machine
- SSH client (Terminal on Mac/Linux, PuTTY on Windows)
- Text editor for viewing/editing files
- Web browser for AWS console access

### Technical Knowledge
- Basic Linux command line usage
- Understanding of SSH key pairs
- Basic networking concepts

## Troubleshooting

### Cannot Connect to EC2 Instance
- Check security group allows SSH (port 22) from your IP
- Verify SSH key permissions: `chmod 400 your-key.pem`
- Ensure instance is running and has public IP

### Scripts Won't Execute
- Check file permissions: `chmod +x script-name.sh`
- Verify Python 3 is installed: `python3 --version`
- Install missing packages: `pip3 install package-name`

### Permission Denied Errors
- Use `sudo` for system-level operations
- Check file ownership: `ls -la filename`
- Ensure you're in the correct directory

## Support

- **Students**: Contact your instructor during office hours
- **Instructors**: Refer to the detailed Instructor Guide
- **Technical Issues**: Check AWS documentation and course resources

## Version Information

- **Lab Version**: 1.0
- **Created**: July 2025
- **Compatible**: Ubuntu 22.04 LTS, Python 3.8+, OpenSSL 1.1+