# CS4910 Lab 1 - Changelog

## Version 1.0 (July 2025)

### Initial Release
- Complete lab assignment for Fall 2025 semester
- AWS EC2 integration for hands-on cloud security experience
- Five comprehensive analysis scripts
- Detailed instructor guide with grading rubrics
- Student report template and documentation

### Features Added
- **AWS Environment Setup**: Automated script for EC2 configuration
- **CIA Triad Analysis**: Interactive tool for security scenario analysis
- **Incident Analysis**: Framework for real-world security incident examination
- **Hash Function Analysis**: Comprehensive cryptographic analysis tools
- **Certificate Analysis**: SSL/TLS certificate examination tools

### Documentation
- Main lab assignment (20+ pages)
- Instructor guide with detailed rubrics
- Student report template
- Installation and setup guides
- Comprehensive README with troubleshooting

### Scripts and Tools
- `aws_setup.sh` - Automated environment configuration
- `cia_analysis.py` - CIA Triad analysis with automated scoring
- `incident_analysis.py` - Security incident analysis framework
- `hash_analysis.py` - Hash function properties and collision analysis
- `certificate_analysis.sh` - PKI and certificate chain analysis

### Educational Components
- Theory integration with practical exercises
- Real-world security incident analysis
- Hands-on cryptographic demonstrations
- AWS cloud security best practices
- Professional security analysis methodologies

### Assessment Framework
- 100-point grading system
- Detailed rubrics for each component
- Multiple assessment methods (technical, conceptual, documentation)
- Academic integrity guidelines

## Future Enhancements (Planned)

### Version 1.1 (Planned for Spring 2026)
- Additional cloud providers (Azure, GCP) support
- Extended cryptographic analysis tools
- Integration with security frameworks (NIST, ISO 27001)
- Advanced incident response scenarios

### Version 1.2 (Planned for Fall 2026)
- Machine learning security analysis components
- IoT security scenarios
- Advanced PKI and certificate transparency analysis
- Automated vulnerability assessment tools

## Known Issues

### Current Limitations
- Scripts optimized for Ubuntu 22.04 LTS (may need adaptation for other distributions)
- Certificate analysis requires internet connectivity
- Some hash analysis demonstrations may be slow on lower-powered instances

### Workarounds
- Use t3.micro or larger instance types for better performance
- Ensure security groups allow HTTPS (443) for certificate analysis
- Reduce hash bit length for faster birthday attack demonstrations

## Compatibility

### Tested Environments
- **Operating System**: Ubuntu 22.04 LTS
- **Python**: 3.8, 3.9, 3.10, 3.11
- **OpenSSL**: 1.1.1+
- **AWS Instance Types**: t3.micro, t3.small, t3.medium

### Dependencies
- Python packages: requests, cryptography, beautifulsoup4
- System tools: curl, wget, openssl, git
- Network access for certificate analysis and incident research

## Contributing

### For Instructors
- Feedback on lab effectiveness and student outcomes
- Suggestions for additional scenarios or analysis tools
- Reports of technical issues or compatibility problems
- Contributions of new scripts or enhancements

### For Students
- Bug reports for script issues
- Suggestions for improved documentation
- Feedback on lab difficulty and clarity

## License and Usage

This educational material is designed for academic use in computer security courses. Instructors are encouraged to adapt and modify the content for their specific needs while maintaining academic integrity standards.

## Contact and Support

For questions, issues, or contributions related to this lab:
- Review the comprehensive Instructor Guide
- Check the troubleshooting sections in documentation
- Consult AWS and OpenSSL official documentation
- Contact course instructor for academic support

---

*CS4910: Introduction to Computer Security*  
*University of Colorado Colorado Springs*  
*Instructor: Rhett Saunders*