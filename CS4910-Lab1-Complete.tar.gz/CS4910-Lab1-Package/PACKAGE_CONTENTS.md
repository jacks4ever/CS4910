# CS4910 Lab 1 - Package Contents

## 📦 Complete Lab Package

This package contains everything needed to deploy and run CS4910 Lab 1: Security Fundamentals and AWS Environment Setup.

## 📋 File Inventory

### Core Lab Documents
- **`CS4910_Lab1_Security_Fundamentals.md`** (20KB) - Main lab assignment with detailed instructions
- **`CS4910_Lab1_Instructor_Guide.md`** (14KB) - Comprehensive instructor guide with grading rubrics
- **`CS4910_Lab1_Report_Template.md`** (11KB) - Student report template

### Setup and Documentation
- **`README.md`** (8KB) - Overview and quick start guide
- **`INSTALLATION.md`** (3KB) - Detailed installation and setup instructions
- **`CHANGELOG.md`** (4KB) - Version history and planned enhancements
- **`PACKAGE_CONTENTS.md`** (This file) - Complete package inventory

### Analysis Scripts (`scripts/` directory)
- **`aws_setup.sh`** (9KB) - Automated AWS environment setup script
- **`cia_analysis.py`** (8KB) - CIA Triad analysis tool with interactive interface
- **`incident_analysis.py`** (14KB) - Security incident analysis framework
- **`hash_analysis.py`** (14KB) - Hash function analysis with collision demonstrations
- **`certificate_analysis.sh`** (13KB) - SSL/TLS certificate analysis tool

## 🎯 Lab Components Overview

### Part 1: AWS Environment Setup (20 points)
- **Purpose**: Set up secure EC2 instance for security analysis
- **Tools**: `aws_setup.sh`
- **Skills**: Cloud security, infrastructure management

### Part 2: CIA Triad Analysis (25 points)
- **Purpose**: Apply security fundamentals to real-world scenarios
- **Tools**: `cia_analysis.py`
- **Skills**: Security framework application, risk assessment

### Part 3: Security Incident Analysis (20 points)
- **Purpose**: Analyze real security breaches using established frameworks
- **Tools**: `incident_analysis.py`
- **Skills**: Incident response, security property analysis

### Part 4: Hash Function Investigation (25 points)
- **Purpose**: Explore cryptographic hash functions and collision resistance
- **Tools**: `hash_analysis.py`
- **Skills**: Cryptographic understanding, mathematical analysis

### Part 5: Certificate Analysis (10 points)
- **Purpose**: Examine digital certificates and PKI
- **Tools**: `certificate_analysis.sh`
- **Skills**: PKI understanding, certificate validation

## 🛠️ Technical Specifications

### System Requirements
- **Operating System**: Ubuntu 22.04 LTS (recommended)
- **Python**: 3.8 or higher
- **Memory**: 1GB RAM minimum (t3.micro sufficient)
- **Storage**: 8GB available space
- **Network**: Internet connectivity required

### Dependencies
- **System Packages**: curl, wget, openssl, git, python3, python3-pip
- **Python Packages**: requests, cryptography, beautifulsoup4
- **AWS**: EC2 instance with appropriate security groups

### Estimated Completion Time
- **Setup**: 30-60 minutes
- **Lab Completion**: 4-6 hours
- **Report Writing**: 2-3 hours
- **Total**: 6-10 hours

## 📊 Assessment Framework

### Grading Distribution
- AWS Environment Setup: 20 points
- CIA Triad Analysis: 25 points
- Security Incident Analysis: 20 points
- Hash Function Investigation: 25 points
- Certificate Analysis: 10 points
- **Total**: 100 points

### Assessment Methods
- **Technical Implementation**: Script execution and configuration
- **Conceptual Understanding**: Analysis quality and explanations
- **Documentation**: Report completeness and clarity
- **Security Practices**: Proper security configuration and awareness

## 🚀 Quick Start Commands

### Extract Package
```bash
tar -xzf CS4910-Lab1-Complete.tar.gz
cd CS4910-Lab1-Package
```

### Upload to AWS EC2
```bash
scp -i your-key.pem -r scripts/ ubuntu@your-ec2-ip:~/
scp -i your-key.pem *.md ubuntu@your-ec2-ip:~/
```

### Run Setup on EC2
```bash
chmod +x scripts/aws_setup.sh
./scripts/aws_setup.sh
```

### Begin Analysis
```bash
python3 scripts/cia_analysis.py
python3 scripts/incident_analysis.py
python3 scripts/hash_analysis.py
./scripts/certificate_analysis.sh
```

## 📚 Educational Outcomes

Students will gain practical experience with:
- AWS cloud security configuration
- Security framework application (CIA Triad)
- Real-world incident analysis
- Cryptographic concepts and implementations
- Public key infrastructure and digital certificates
- Command-line security tools
- Technical documentation and reporting

## 🔒 Security Considerations

This lab emphasizes security best practices:
- Proper AWS security group configuration
- SSH key management and file permissions
- Principle of least privilege
- Secure communication protocols
- Data protection and privacy awareness

## 📞 Support and Resources

### For Students
- Follow the main lab document step-by-step
- Use the report template for submission
- Contact instructor for academic support
- Refer to troubleshooting sections for technical issues

### For Instructors
- Review the comprehensive Instructor Guide
- Test all scripts in your environment before deployment
- Customize grading rubrics as needed
- Monitor student progress and provide guidance

## 📈 Package Statistics

- **Total Files**: 11
- **Total Size**: ~33KB compressed, ~120KB uncompressed
- **Documentation**: 7 files (~75KB)
- **Scripts**: 5 files (~45KB)
- **Lines of Code**: ~1,500 lines across all scripts
- **Documentation Pages**: ~60 pages total

---

**Package Version**: 1.0  
**Created**: July 2025  
**Compatible**: CS4910 Fall 2025 and later  
**Instructor**: Rhett Saunders  
**Institution**: University of Colorado Colorado Springs