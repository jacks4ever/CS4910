# CS 4910: Introduction to Computer Security
## Lab Assignment 1: Instructor Guide
**Fall 2025 Semester**  
**University of Colorado Colorado Springs**  
**Instructor: Rhett Saunders**

---

## Overview

This instructor guide provides comprehensive information for administering Lab 1 of CS4910. The lab combines theoretical security concepts with practical AWS cloud computing experience, giving students hands-on exposure to security analysis tools and methodologies.

---

## Learning Objectives Assessment

### Primary Objectives
1. **Cloud Security Setup** - Students demonstrate ability to securely configure AWS infrastructure
2. **CIA Triad Application** - Students apply fundamental security concepts to real-world scenarios
3. **Incident Analysis** - Students analyze actual security breaches using established frameworks
4. **Cryptographic Understanding** - Students explore hash function properties and collision resistance
5. **PKI Comprehension** - Students examine digital certificates and trust chains

### Skills Developed
- AWS EC2 instance management and security configuration
- Command-line security tool usage (OpenSSL, Python scripts)
- Security framework application (CIA Triad, incident analysis)
- Technical writing and documentation
- Critical thinking about security trade-offs

---

## Pre-Lab Preparation

### AWS Account Setup
1. **Educational Credits**: Ensure students have AWS Educate accounts with sufficient credits
2. **Account Limits**: Verify students can launch t3.micro instances in their preferred region
3. **Support**: Prepare troubleshooting guide for common AWS issues

### Infrastructure Requirements
- **Instance Type**: t3.micro (free tier eligible)
- **AMI**: Ubuntu 22.04 LTS
- **Security Groups**: SSH (22), HTTP (80), HTTPS (443)
- **Key Pairs**: Students must create and securely store their key pairs

### Tool Verification
Ensure the following tools work in the lab environment:
- OpenSSL (certificate analysis)
- Python 3.8+ with required packages
- Network connectivity for certificate retrieval
- Git for potential script updates

---

## Detailed Grading Rubric

### Part 1: AWS Environment Setup (20 points)

| Criteria | Excellent (18-20) | Good (15-17) | Satisfactory (12-14) | Needs Improvement (0-11) |
|----------|-------------------|--------------|---------------------|--------------------------|
| **Instance Configuration** | Perfect security group setup, proper instance type, all requirements met | Minor configuration issues, mostly correct | Some configuration problems, basic functionality works | Major configuration issues, security concerns |
| **Security Implementation** | Excellent security practices, proper key management, firewall configured | Good security practices, minor oversights | Basic security implemented, some gaps | Poor security practices, significant vulnerabilities |
| **Documentation** | Clear screenshots, detailed connection process, troubleshooting notes | Good documentation, minor gaps | Basic documentation, meets requirements | Poor documentation, missing key elements |
| **Connection Verification** | Successful SSH connection, all tools working, environment ready | Connection works, minor tool issues | Basic connection established | Connection problems, environment not ready |

### Part 2: CIA Triad Analysis (25 points)

| Criteria | Excellent (23-25) | Good (19-22) | Satisfactory (15-18) | Needs Improvement (0-14) |
|----------|-------------------|--------------|---------------------|--------------------------|
| **Scenario Understanding** | Deep understanding of all scenarios, nuanced analysis | Good understanding, mostly accurate analysis | Basic understanding, adequate analysis | Poor understanding, superficial analysis |
| **CIA Application** | Perfect application of CIA concepts, excellent justifications | Good CIA application, solid justifications | Basic CIA application, adequate justifications | Poor CIA application, weak justifications |
| **Rating Accuracy** | Highly accurate ratings with excellent reasoning | Mostly accurate ratings with good reasoning | Generally accurate ratings with basic reasoning | Inaccurate ratings, poor reasoning |
| **Script Usage** | Excellent use of analysis script, comprehensive output | Good script usage, adequate output | Basic script usage, meets requirements | Poor script usage, incomplete output |
| **Critical Thinking** | Exceptional analysis depth, considers multiple perspectives | Good analysis depth, some perspective consideration | Basic analysis, limited perspective | Shallow analysis, single perspective |

### Part 3: Security Incident Analysis (20 points)

| Criteria | Excellent (18-20) | Good (15-17) | Satisfactory (12-14) | Needs Improvement (0-11) |
|----------|-------------------|--------------|---------------------|--------------------------|
| **Incident Selection** | Recent, significant incident from reputable source | Good incident selection, credible source | Adequate incident, acceptable source | Poor incident selection, questionable source |
| **Analysis Framework** | Excellent application of security framework, comprehensive analysis | Good framework application, solid analysis | Basic framework application, adequate analysis | Poor framework application, weak analysis |
| **Writing Quality** | Excellent writing, clear structure, professional presentation | Good writing, mostly clear, well organized | Adequate writing, meets requirements | Poor writing, unclear, disorganized |
| **Security Property Identification** | Perfect identification of affected properties with excellent justification | Good identification with solid justification | Basic identification with adequate justification | Poor identification, weak justification |

### Part 4: Hash Function Investigation (25 points)

| Criteria | Excellent (23-25) | Good (19-22) | Satisfactory (15-18) | Needs Improvement (0-14) |
|----------|-------------------|--------------|---------------------|--------------------------|
| **Theoretical Understanding** | Excellent grasp of collision resistance, birthday paradox, pigeonhole principle | Good understanding of key concepts | Basic understanding, adequate explanations | Poor understanding, incorrect explanations |
| **Script Execution** | Perfect script execution, comprehensive analysis of results | Good script execution, adequate analysis | Basic script execution, meets requirements | Poor script execution, incomplete results |
| **Mathematical Concepts** | Excellent explanation of mathematical principles | Good explanation of mathematical concepts | Basic explanation, adequate understanding | Poor explanation, mathematical errors |
| **Practical Application** | Excellent connection between theory and practice | Good theory-practice connection | Basic connection made | Poor or no connection between theory and practice |

### Part 5: Public-Key Certificate Analysis (10 points)

| Criteria | Excellent (9-10) | Good (7-8) | Satisfactory (6) | Needs Improvement (0-5) |
|----------|------------------|------------|------------------|-------------------------|
| **Certificate Extraction** | Perfect certificate analysis, all information extracted correctly | Good analysis, minor information gaps | Basic analysis, adequate information | Poor analysis, significant information missing |
| **Tool Usage** | Excellent use of OpenSSL and analysis tools | Good tool usage, minor issues | Basic tool usage, meets requirements | Poor tool usage, significant problems |
| **Understanding** | Excellent understanding of PKI concepts, certificate purpose | Good PKI understanding | Basic PKI understanding | Poor PKI understanding |

---

## Common Student Issues and Solutions

### AWS-Related Issues

**Issue**: Students cannot connect to EC2 instance
- **Cause**: Incorrect security group configuration, wrong key pair, or network issues
- **Solution**: Verify security group allows SSH from student's IP, check key pair permissions (chmod 400)

**Issue**: "Permission denied" when using SSH key
- **Cause**: Incorrect file permissions on private key
- **Solution**: `chmod 400 keyfile.pem`

**Issue**: Instance not accessible after setup
- **Cause**: Firewall misconfiguration or service issues
- **Solution**: Check security groups, verify instance is running, check system logs

### Script-Related Issues

**Issue**: Python scripts fail to run
- **Cause**: Missing dependencies, Python version issues
- **Solution**: Verify Python 3.8+, install required packages with pip3

**Issue**: Certificate analysis fails
- **Cause**: Network connectivity, OpenSSL configuration, or target site issues
- **Solution**: Test with different domains, check network connectivity, verify OpenSSL installation

**Issue**: Hash analysis script runs slowly
- **Cause**: Large hash space for birthday attack simulation
- **Solution**: Reduce hash bits for demonstration (16-bit recommended)

### Conceptual Issues

**Issue**: Students struggle with CIA Triad application
- **Solution**: Provide additional examples, emphasize real-world consequences

**Issue**: Confusion about collision resistance types
- **Solution**: Use birthday paradox analogy, provide visual examples

**Issue**: Certificate chain understanding
- **Solution**: Draw trust hierarchy diagrams, explain CA role

---

## Assessment Guidelines

### Grading Philosophy
- **Process over Product**: Reward good methodology even if results aren't perfect
- **Learning Evidence**: Look for evidence of understanding, not just correct answers
- **Security Mindset**: Reward security-conscious thinking and practices

### Red Flags for Academic Integrity
- Identical script outputs across multiple students
- Unrealistic analysis completion times
- Copy-pasted text without understanding
- Missing intermediate files or screenshots

### Partial Credit Guidelines
- **AWS Setup**: Give partial credit for attempted configuration even if not perfect
- **Analysis Scripts**: Credit for script execution attempts and partial results
- **Written Analysis**: Credit for effort and partial understanding
- **Screenshots**: Accept alternative evidence if screenshots are problematic

---

## Extension Activities

For advanced students or those finishing early:

### Advanced AWS Security
- Configure AWS CloudTrail for audit logging
- Set up AWS Config for compliance monitoring
- Implement AWS Systems Manager for patch management

### Extended Cryptographic Analysis
- Compare hash function performance benchmarks
- Implement simple hash collision detection
- Analyze certificate revocation mechanisms

### Security Research
- Research recent PKI vulnerabilities
- Analyze certificate transparency logs
- Investigate DNS security extensions (DNSSEC)

---

## Lab Variations

### For Different Class Sizes

**Small Classes (< 20 students)**
- Individual AWS accounts and instances
- Detailed one-on-one troubleshooting
- Extended discussion of results

**Large Classes (> 50 students)**
- Shared AWS accounts with student sub-accounts
- Group troubleshooting sessions
- Automated grading for script outputs

### For Different Skill Levels

**Beginner-Friendly Modifications**
- Pre-configured AWS instances
- Simplified script interfaces
- Additional guided examples

**Advanced Modifications**
- Custom security group configurations
- Extended cryptographic analysis
- Research component on recent vulnerabilities

---

## Time Management

### Recommended Schedule
- **Week 1**: Lab assignment, AWS account setup
- **Week 2**: AWS instance configuration, begin analysis
- **Week 3**: Complete analysis scripts, documentation
- **Week 4**: Final report submission, peer review

### In-Class Time Allocation
- **30 minutes**: AWS setup troubleshooting
- **45 minutes**: Script execution and analysis
- **30 minutes**: Discussion of results and concepts
- **15 minutes**: Questions and wrap-up

---

## Resources for Students

### Official Documentation
- [AWS EC2 User Guide](https://docs.aws.amazon.com/ec2/)
- [OpenSSL Documentation](https://www.openssl.org/docs/)
- [Python Cryptography Library](https://cryptography.io/)

### Additional Learning Materials
- [NIST Cybersecurity Framework](https://www.nist.gov/cyberframework)
- [RFC 5280 - Internet X.509 PKI Certificate](https://tools.ietf.org/html/rfc5280)
- [OWASP Security Testing Guide](https://owasp.org/www-project-web-security-testing-guide/)

### Video Tutorials
- AWS EC2 Getting Started
- OpenSSL Certificate Analysis
- Python Security Scripting

---

## Continuous Improvement

### Student Feedback Collection
- Post-lab survey on difficulty and clarity
- Technical issue tracking
- Suggestion collection for improvements

### Lab Evolution
- Update scripts based on student feedback
- Refresh security incidents for current relevance
- Adapt to new AWS features and pricing

### Assessment Refinement
- Analyze grade distributions
- Identify common misconceptions
- Adjust rubric based on student performance

---

## Appendix: Sample Solutions

### CIA Triad Analysis - ATM System
- **Confidentiality: 5/5** - PIN and financial data must be absolutely protected
- **Integrity: 5/5** - Transaction accuracy is critical for financial operations
- **Availability: 3/5** - Important for customer service but not life-critical

### Security Incident Example Analysis
**Incident**: SolarWinds Supply Chain Attack (2020)
- **Affected Properties**: Confidentiality, Integrity, Authenticity, Accountability
- **Impact Level**: 5/5 (Critical)
- **Analysis**: Nation-state attack compromising software supply chain affecting thousands of organizations

### Hash Function Theoretical Answers
**Question**: Is H(x) ≠ H(x') always true for x ≠ x'?
**Answer**: No, due to the pigeonhole principle. Infinite input space maps to finite output space, guaranteeing collisions exist mathematically.

---

**Document Version**: 1.0  
**Last Updated**: July 2025  
**Next Review**: December 2025