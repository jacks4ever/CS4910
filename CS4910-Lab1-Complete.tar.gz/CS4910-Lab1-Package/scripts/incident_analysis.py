#!/usr/bin/env python3
"""
CS4910 Lab 1 - Security Incident Analysis Tool
University of Colorado Colorado Springs
Fall 2025 - Instructor: Rhett Saunders

This script helps students analyze real-world security incidents using established frameworks.
"""

import json
import requests
from datetime import datetime
from urllib.parse import urlparse

class SecurityIncidentAnalyzer:
    def __init__(self):
        self.incident_data = {}
        self.security_properties = [
            'Confidentiality',
            'Integrity', 
            'Availability',
            'Authenticity',
            'Accountability'
        ]
    
    def analyze_incident(self, title, date, source_url, description, affected_properties, impact_level, attack_vector="Unknown"):
        """
        Analyze a security incident using the extended CIA framework
        
        Args:
            title: Incident title
            date: Date of incident (YYYY-MM-DD format)
            source_url: URL of news source
            description: Brief description of the incident
            affected_properties: List of affected security properties
            impact_level: Scale 1-5 (5 = highest impact)
            attack_vector: How the attack was carried out
        """
        
        # Validate inputs
        if not all([title, date, source_url, description]):
            raise ValueError("All required fields must be provided")
        
        if impact_level not in range(1, 6):
            raise ValueError("Impact level must be between 1 and 5")
        
        # Validate affected properties
        invalid_properties = [prop for prop in affected_properties if prop not in self.security_properties]
        if invalid_properties:
            raise ValueError(f"Invalid security properties: {invalid_properties}")
        
        self.incident_data = {
            'title': title,
            'date': date,
            'source_url': source_url,
            'source_domain': urlparse(source_url).netloc,
            'description': description,
            'affected_properties': affected_properties,
            'impact_level': impact_level,
            'attack_vector': attack_vector,
            'analysis_date': datetime.now().isoformat(),
            'analysis_version': '1.0'
        }
        
        self._display_analysis()
        return self.incident_data
    
    def _display_analysis(self):
        """Display the incident analysis in a formatted way"""
        print(f"\n{'='*60}")
        print("SECURITY INCIDENT ANALYSIS")
        print(f"{'='*60}")
        
        print(f"Incident: {self.incident_data['title']}")
        print(f"Date: {self.incident_data['date']}")
        print(f"Source: {self.incident_data['source_domain']}")
        print(f"Impact Level: {self.incident_data['impact_level']}/5 {self._get_impact_indicator()}")
        print(f"Attack Vector: {self.incident_data['attack_vector']}")
        
        print(f"\nDescription:")
        print(f"  {self.incident_data['description']}")
        
        print(f"\nAffected Security Properties:")
        for prop in self.incident_data['affected_properties']:
            print(f"  ✓ {prop}")
        
        # Show unaffected properties
        unaffected = [prop for prop in self.security_properties if prop not in self.incident_data['affected_properties']]
        if unaffected:
            print(f"\nUnaffected Security Properties:")
            for prop in unaffected:
                print(f"  ○ {prop}")
        
        self._calculate_metrics()
    
    def _get_impact_indicator(self):
        """Get visual indicator for impact level"""
        level = self.incident_data['impact_level']
        if level <= 2:
            return "🟢 (Low)"
        elif level <= 3:
            return "🟡 (Medium)"
        elif level <= 4:
            return "🟠 (High)"
        else:
            return "🔴 (Critical)"
    
    def _calculate_metrics(self):
        """Calculate and display analysis metrics"""
        total_properties = len(self.security_properties)
        affected_count = len(self.incident_data['affected_properties'])
        coverage_percentage = (affected_count / total_properties) * 100
        
        print(f"\n{'='*40}")
        print("ANALYSIS METRICS")
        print(f"{'='*40}")
        print(f"Security Property Coverage: {coverage_percentage:.1f}% ({affected_count}/{total_properties})")
        print(f"Incident Severity Score: {self.incident_data['impact_level'] * affected_count}/25")
        
        # Provide analysis insights
        self._provide_insights()
    
    def _provide_insights(self):
        """Provide analytical insights based on the incident data"""
        print(f"\n{'='*40}")
        print("ANALYTICAL INSIGHTS")
        print(f"{'='*40}")
        
        affected = self.incident_data['affected_properties']
        impact = self.incident_data['impact_level']
        
        # CIA Triad analysis
        cia_affected = [prop for prop in affected if prop in ['Confidentiality', 'Integrity', 'Availability']]
        if len(cia_affected) == 3:
            print("• Complete CIA Triad compromise - indicates severe systemic failure")
        elif len(cia_affected) == 2:
            print("• Multiple CIA properties affected - suggests significant security breach")
        elif len(cia_affected) == 1:
            print(f"• Primary impact on {cia_affected[0]} - focused attack vector")
        
        # Extended properties analysis
        if 'Authenticity' in affected:
            print("• Authenticity compromised - identity verification systems failed")
        if 'Accountability' in affected:
            print("• Accountability compromised - audit trails may be unreliable")
        
        # Impact assessment
        if impact >= 4:
            print("• High impact incident - likely requires immediate response and remediation")
        elif impact >= 3:
            print("• Moderate impact incident - systematic review and improvements needed")
        else:
            print("• Lower impact incident - good learning opportunity for security awareness")
    
    def generate_report(self):
        """Generate a comprehensive analysis report"""
        if not self.incident_data:
            print("No incident data available for report generation.")
            return
        
        print(f"\n{'='*60}")
        print("COMPREHENSIVE INCIDENT ANALYSIS REPORT")
        print(f"{'='*60}")
        print(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"Analyst: CS4910 Student")
        
        print(f"\n1. INCIDENT OVERVIEW")
        print(f"   Title: {self.incident_data['title']}")
        print(f"   Date: {self.incident_data['date']}")
        print(f"   Source: {self.incident_data['source_url']}")
        
        print(f"\n2. IMPACT ASSESSMENT")
        print(f"   Impact Level: {self.incident_data['impact_level']}/5")
        print(f"   Attack Vector: {self.incident_data['attack_vector']}")
        
        print(f"\n3. SECURITY PROPERTIES ANALYSIS")
        for prop in self.security_properties:
            status = "AFFECTED" if prop in self.incident_data['affected_properties'] else "UNAFFECTED"
            print(f"   {prop}: {status}")
        
        print(f"\n4. DESCRIPTION")
        print(f"   {self.incident_data['description']}")
        
        print(f"\n5. RECOMMENDATIONS")
        self._generate_recommendations()
    
    def _generate_recommendations(self):
        """Generate recommendations based on affected properties"""
        affected = self.incident_data['affected_properties']
        
        if 'Confidentiality' in affected:
            print("   • Implement stronger encryption and access controls")
            print("   • Review data classification and handling procedures")
        
        if 'Integrity' in affected:
            print("   • Deploy integrity monitoring systems")
            print("   • Implement digital signatures and checksums")
        
        if 'Availability' in affected:
            print("   • Improve redundancy and backup systems")
            print("   • Develop incident response and recovery procedures")
        
        if 'Authenticity' in affected:
            print("   • Strengthen authentication mechanisms (MFA)")
            print("   • Review identity verification processes")
        
        if 'Accountability' in affected:
            print("   • Enhance logging and audit trail systems")
            print("   • Implement non-repudiation mechanisms")
    
    def save_analysis(self, filename="incident_analysis.json"):
        """Save the incident analysis to a JSON file"""
        if not self.incident_data:
            print("No incident data to save.")
            return
        
        try:
            with open(filename, 'w') as f:
                json.dump(self.incident_data, f, indent=2)
            print(f"\nAnalysis saved to: {filename}")
        except Exception as e:
            print(f"Error saving analysis: {e}")

def main():
    """Main function with example and template for students"""
    analyzer = SecurityIncidentAnalyzer()
    
    print("CS4910 Lab 1 - Security Incident Analysis Tool")
    print("University of Colorado Colorado Springs")
    print("Fall 2025 - Instructor: Rhett Saunders")
    print("\nThis tool helps analyze real-world security incidents.")
    
    # Example analysis
    print("\n" + "="*60)
    print("EXAMPLE ANALYSIS - Equifax Data Breach (2017)")
    print("="*60)
    
    example_analysis = analyzer.analyze_incident(
        title="Equifax Data Breach",
        date="2017-09-07",
        source_url="https://www.cnn.com/2017/09/07/tech/equifax-data-breach/index.html",
        description="Cybercriminals exploited a vulnerability in Apache Struts to access personal information of 147 million Americans, including SSNs, birth dates, addresses, and driver's license numbers.",
        affected_properties=['Confidentiality', 'Authenticity', 'Accountability'],
        impact_level=5,
        attack_vector="Web application vulnerability (Apache Struts CVE-2017-5638)"
    )
    
    analyzer.generate_report()
    
    print("\n" + "="*60)
    print("STUDENT ASSIGNMENT")
    print("="*60)
    print("Find a recent security incident (within last 2 years) and analyze it.")
    print("\nRequired elements:")
    print("1. Reputable news source (major news outlet, security blog, etc.)")
    print("2. Clear description of what happened")
    print("3. Analysis of which security properties were affected")
    print("4. Impact assessment (1-5 scale)")
    print("5. Identification of attack vector if known")
    
    print("\n" + "-"*50)
    print("TEMPLATE FOR STUDENT ANALYSIS")
    print("-"*50)
    print("""
# Example template:
analyzer = SecurityIncidentAnalyzer()

student_analysis = analyzer.analyze_incident(
    title="Your Incident Title Here",
    date="YYYY-MM-DD",
    source_url="https://your-news-source.com/article",
    description="Detailed description of the incident...",
    affected_properties=['Confidentiality', 'Integrity'],  # Select applicable ones
    impact_level=4,  # Your assessment 1-5
    attack_vector="How the attack was carried out"
)

analyzer.generate_report()
analyzer.save_analysis("my_incident_analysis.json")
    """)
    
    # Save example analysis
    analyzer.save_analysis("example_incident_analysis.json")

if __name__ == "__main__":
    main()