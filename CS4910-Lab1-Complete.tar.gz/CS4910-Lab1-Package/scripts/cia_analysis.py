#!/usr/bin/env python3
"""
CS4910 Lab 1 - CIA Triad Analysis Tool
University of Colorado Colorado Springs
Fall 2025 - Instructor: Rhett Saunders

This script helps students analyze security scenarios using the CIA Triad framework.
"""

import json
import sys
from datetime import datetime

class CIAAnalyzer:
    def __init__(self):
        self.scenarios = []
        self.analysis_results = {}
    
    def analyze_scenario(self, scenario_name, confidentiality, integrity, availability, justification):
        """
        Analyze a scenario for CIA requirements
        
        Args:
            scenario_name: Name of the scenario
            confidentiality: Importance level (1-5, 5 being highest)
            integrity: Importance level (1-5, 5 being highest)  
            availability: Importance level (1-5, 5 being highest)
            justification: Dictionary with explanations for each rating
        """
        
        print(f"\n{'='*50}")
        print(f"CIA Analysis: {scenario_name}")
        print(f"{'='*50}")
        
        print(f"Confidentiality: {confidentiality}/5")
        print(f"  Justification: {justification['confidentiality']}")
        
        print(f"\nIntegrity: {integrity}/5")
        print(f"  Justification: {justification['integrity']}")
        
        print(f"\nAvailability: {availability}/5")
        print(f"  Justification: {justification['availability']}")
        
        # Calculate overall risk assessment
        total_score = confidentiality + integrity + availability
        if total_score <= 8:
            risk_level = "Low"
            risk_color = "🟢"
        elif total_score <= 12:
            risk_level = "Medium" 
            risk_color = "🟡"
        else:
            risk_level = "High"
            risk_color = "🔴"
        
        print(f"\nOverall Security Priority: {risk_color} {risk_level}")
        print(f"Combined Score: {total_score}/15")
        
        # Identify primary concern
        scores = {'Confidentiality': confidentiality, 'Integrity': integrity, 'Availability': availability}
        primary_concern = max(scores, key=scores.get)
        print(f"Primary Security Concern: {primary_concern}")
        
        result = {
            'scenario': scenario_name,
            'timestamp': datetime.now().isoformat(),
            'scores': {
                'confidentiality': confidentiality,
                'integrity': integrity,
                'availability': availability,
                'total': total_score
            },
            'justification': justification,
            'risk_level': risk_level,
            'primary_concern': primary_concern
        }
        
        self.analysis_results[scenario_name] = result
        return result
    
    def generate_summary_report(self):
        """Generate a summary report of all analyses"""
        if not self.analysis_results:
            print("No analysis data available for report generation.")
            return
        
        print(f"\n{'='*60}")
        print("CIA TRIAD ANALYSIS SUMMARY REPORT")
        print(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"{'='*60}")
        
        # Summary statistics
        total_scenarios = len(self.analysis_results)
        avg_scores = {'confidentiality': 0, 'integrity': 0, 'availability': 0}
        risk_distribution = {'Low': 0, 'Medium': 0, 'High': 0}
        
        for result in self.analysis_results.values():
            for aspect in avg_scores:
                avg_scores[aspect] += result['scores'][aspect]
            risk_distribution[result['risk_level']] += 1
        
        # Calculate averages
        for aspect in avg_scores:
            avg_scores[aspect] = avg_scores[aspect] / total_scenarios
        
        print(f"\nScenarios Analyzed: {total_scenarios}")
        print(f"\nAverage CIA Scores:")
        print(f"  Confidentiality: {avg_scores['confidentiality']:.1f}/5")
        print(f"  Integrity: {avg_scores['integrity']:.1f}/5")
        print(f"  Availability: {avg_scores['availability']:.1f}/5")
        
        print(f"\nRisk Level Distribution:")
        for level, count in risk_distribution.items():
            percentage = (count / total_scenarios) * 100
            print(f"  {level}: {count} scenarios ({percentage:.1f}%)")
        
        # Scenario ranking by total score
        sorted_scenarios = sorted(self.analysis_results.items(), 
                                key=lambda x: x[1]['scores']['total'], reverse=True)
        
        print(f"\nScenarios Ranked by Security Priority:")
        for i, (name, data) in enumerate(sorted_scenarios, 1):
            print(f"  {i}. {name} - {data['scores']['total']}/15 ({data['risk_level']})")
    
    def save_results(self, filename="cia_analysis_results.json"):
        """Save analysis results to JSON file"""
        try:
            with open(filename, 'w') as f:
                json.dump(self.analysis_results, f, indent=2)
            print(f"\nResults saved to: {filename}")
        except Exception as e:
            print(f"Error saving results: {e}")

def main():
    """Main function with example scenarios for students to complete"""
    analyzer = CIAAnalyzer()
    
    print("CS4910 Lab 1 - CIA Triad Analysis Tool")
    print("University of Colorado Colorado Springs")
    print("Fall 2025 - Instructor: Rhett Saunders")
    print("\nThis tool helps analyze security scenarios using the CIA Triad framework.")
    
    # Example scenario - ATM System (students should complete the others)
    print("\n" + "="*60)
    print("EXAMPLE ANALYSIS - ATM System")
    print("="*60)
    
    atm_justification = {
        'confidentiality': "PIN and account information must be protected from unauthorized access. Compromise could lead to financial theft.",
        'integrity': "Transaction data and account balances must be accurate. Data corruption could cause financial losses.",
        'availability': "ATM must be accessible when customers need cash. Downtime causes customer inconvenience but not life-threatening."
    }
    
    analyzer.analyze_scenario(
        "ATM System",
        confidentiality=5,  # Highest - financial data protection critical
        integrity=5,        # Highest - accurate transactions essential  
        availability=3,     # Medium - important but not life-critical
        justification=atm_justification
    )
    
    print("\n" + "="*60)
    print("STUDENT ASSIGNMENT")
    print("="*60)
    print("Complete the analysis for the remaining scenarios:")
    print("1. Domain Name System (DNS)")
    print("2. Implanted Defibrillator") 
    print("3. Online Voting System")
    print("4. Automated Metro Train System")
    print("\nFor each scenario, consider:")
    print("- What data/services need protection?")
    print("- What are the consequences of compromise?")
    print("- Who are the stakeholders affected?")
    print("- What is the criticality to human safety/welfare?")
    
    # Template for students to fill in
    print("\n" + "-"*50)
    print("TEMPLATE FOR STUDENT ANALYSIS")
    print("-"*50)
    print("""
# Example for DNS System:
dns_justification = {
    'confidentiality': "Your analysis here...",
    'integrity': "Your analysis here...", 
    'availability': "Your analysis here..."
}

analyzer.analyze_scenario(
    "DNS System",
    confidentiality=X,  # Your rating 1-5
    integrity=X,        # Your rating 1-5
    availability=X,     # Your rating 1-5
    justification=dns_justification
)
    """)
    
    # Generate report for completed analyses
    analyzer.generate_summary_report()
    analyzer.save_results("cia_analysis_results.json")

if __name__ == "__main__":
    main()