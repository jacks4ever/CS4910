#!/bin/bash
# CS4910 Lab 1 - SSL/TLS Certificate Analysis Tool
# University of Colorado Colorado Springs
# Fall 2025 - Instructor: Rhett Saunders

# Default domain to analyze
DOMAIN="${1:-www.uccs.edu}"
PORT="443"
OUTPUT_DIR="certificate_output"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Create output directory
mkdir -p "$OUTPUT_DIR"

echo -e "${BLUE}================================================================${NC}"
echo -e "${BLUE}CS4910 Lab 1 - SSL/TLS Certificate Analysis Tool${NC}"
echo -e "${BLUE}University of Colorado Colorado Springs${NC}"
echo -e "${BLUE}Fall 2025 - Instructor: Rhett Saunders${NC}"
echo -e "${BLUE}================================================================${NC}"
echo -e "Analyzing certificate for: ${GREEN}$DOMAIN${NC}"
echo -e "Port: ${GREEN}$PORT${NC}"
echo ""

# Function to check if openssl is available
check_openssl() {
    if ! command -v openssl &> /dev/null; then
        echo -e "${RED}Error: OpenSSL is not installed or not in PATH${NC}"
        echo "Please install OpenSSL to use this tool"
        exit 1
    fi
    echo -e "${GREEN}✓ OpenSSL found: $(openssl version)${NC}"
}

# Function to get certificate from server
get_certificate() {
    echo -e "\n${YELLOW}=== Retrieving Certificate ===${NC}"
    
    # Get the certificate and save to file
    echo -e "Connecting to ${DOMAIN}:${PORT}..."
    
    # Use timeout to prevent hanging
    timeout 10 openssl s_client -connect "$DOMAIN:$PORT" -servername "$DOMAIN" \
        -verify_return_error </dev/null 2>/dev/null | \
        openssl x509 -outform PEM > "$OUTPUT_DIR/certificate.pem" 2>/dev/null
    
    if [ $? -eq 0 ] && [ -s "$OUTPUT_DIR/certificate.pem" ]; then
        echo -e "${GREEN}✓ Certificate retrieved successfully${NC}"
        return 0
    else
        echo -e "${RED}✗ Failed to retrieve certificate${NC}"
        echo "This could be due to:"
        echo "  - Network connectivity issues"
        echo "  - Invalid domain name"
        echo "  - Certificate/SSL configuration problems"
        return 1
    fi
}

# Function to display certificate details
show_certificate_details() {
    echo -e "\n${YELLOW}=== Certificate Details ===${NC}"
    
    if [ ! -f "$OUTPUT_DIR/certificate.pem" ]; then
        echo -e "${RED}Certificate file not found${NC}"
        return 1
    fi
    
    # Display human-readable certificate information
    openssl x509 -in "$OUTPUT_DIR/certificate.pem" -noout -text | tee "$OUTPUT_DIR/certificate_details.txt"
}

# Function to extract and display key information
extract_key_info() {
    echo -e "\n${YELLOW}=== Key Certificate Information ===${NC}"
    
    if [ ! -f "$OUTPUT_DIR/certificate.pem" ]; then
        echo -e "${RED}Certificate file not found${NC}"
        return 1
    fi
    
    # Subject (who the certificate is for)
    echo -e "${BLUE}Subject (Certificate Owner):${NC}"
    SUBJECT=$(openssl x509 -in "$OUTPUT_DIR/certificate.pem" -noout -subject | sed 's/subject=//')
    echo "  $SUBJECT"
    echo "$SUBJECT" > "$OUTPUT_DIR/subject.txt"
    
    # Issuer (who issued the certificate)
    echo -e "\n${BLUE}Issuer (Certificate Authority):${NC}"
    ISSUER=$(openssl x509 -in "$OUTPUT_DIR/certificate.pem" -noout -issuer | sed 's/issuer=//')
    echo "  $ISSUER"
    echo "$ISSUER" > "$OUTPUT_DIR/issuer.txt"
    
    # Validity dates
    echo -e "\n${BLUE}Validity Period:${NC}"
    echo -e "  Not Before: ${GREEN}$(openssl x509 -in "$OUTPUT_DIR/certificate.pem" -noout -startdate | sed 's/notBefore=//')${NC}"
    echo -e "  Not After:  ${RED}$(openssl x509 -in "$OUTPUT_DIR/certificate.pem" -noout -enddate | sed 's/notAfter=//')${NC}"
    
    openssl x509 -in "$OUTPUT_DIR/certificate.pem" -noout -dates > "$OUTPUT_DIR/validity_dates.txt"
    
    # Serial number
    echo -e "\n${BLUE}Serial Number:${NC}"
    SERIAL=$(openssl x509 -in "$OUTPUT_DIR/certificate.pem" -noout -serial | sed 's/serial=//')
    echo "  $SERIAL"
    echo "$SERIAL" > "$OUTPUT_DIR/serial_number.txt"
}

# Function to calculate and display fingerprints
show_fingerprints() {
    echo -e "\n${YELLOW}=== Certificate Fingerprints ===${NC}"
    
    if [ ! -f "$OUTPUT_DIR/certificate.pem" ]; then
        echo -e "${RED}Certificate file not found${NC}"
        return 1
    fi
    
    # SHA-1 Fingerprint
    echo -e "${BLUE}SHA-1 Fingerprint:${NC}"
    SHA1_FP=$(openssl x509 -in "$OUTPUT_DIR/certificate.pem" -noout -fingerprint -sha1 | sed 's/SHA1 Fingerprint=//')
    echo -e "  ${GREEN}$SHA1_FP${NC}"
    echo "$SHA1_FP" > "$OUTPUT_DIR/sha1_fingerprint.txt"
    
    # SHA-256 Fingerprint
    echo -e "\n${BLUE}SHA-256 Fingerprint:${NC}"
    SHA256_FP=$(openssl x509 -in "$OUTPUT_DIR/certificate.pem" -noout -fingerprint -sha256 | sed 's/SHA256 Fingerprint=//')
    echo -e "  ${GREEN}$SHA256_FP${NC}"
    echo "$SHA256_FP" > "$OUTPUT_DIR/sha256_fingerprint.txt"
    
    # MD5 Fingerprint (for completeness, though deprecated)
    echo -e "\n${BLUE}MD5 Fingerprint (deprecated):${NC}"
    MD5_FP=$(openssl x509 -in "$OUTPUT_DIR/certificate.pem" -noout -fingerprint -md5 | sed 's/MD5 Fingerprint=//')
    echo -e "  ${YELLOW}$MD5_FP${NC}"
    echo "$MD5_FP" > "$OUTPUT_DIR/md5_fingerprint.txt"
}

# Function to show certificate chain
show_certificate_chain() {
    echo -e "\n${YELLOW}=== Certificate Chain Analysis ===${NC}"
    
    echo "Retrieving full certificate chain..."
    
    # Get the full certificate chain
    timeout 10 openssl s_client -connect "$DOMAIN:$PORT" -servername "$DOMAIN" \
        -showcerts </dev/null 2>/dev/null > "$OUTPUT_DIR/full_chain.txt"
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✓ Certificate chain retrieved${NC}"
        
        # Extract and display chain information
        echo -e "\n${BLUE}Certificate Chain Hierarchy:${NC}"
        grep -E "(subject=|issuer=)" "$OUTPUT_DIR/full_chain.txt" | \
        sed 's/subject=/📄 Subject: /' | \
        sed 's/issuer=/🏢 Issuer:  /' | \
        tee "$OUTPUT_DIR/chain_hierarchy.txt"
    else
        echo -e "${RED}✗ Failed to retrieve certificate chain${NC}"
    fi
}

# Function to perform security analysis
security_analysis() {
    echo -e "\n${YELLOW}=== Security Analysis ===${NC}"
    
    if [ ! -f "$OUTPUT_DIR/certificate.pem" ]; then
        echo -e "${RED}Certificate file not found${NC}"
        return 1
    fi
    
    # Check key size
    echo -e "${BLUE}Public Key Analysis:${NC}"
    KEY_INFO=$(openssl x509 -in "$OUTPUT_DIR/certificate.pem" -noout -text | grep -A 1 "Public Key Algorithm")
    echo "$KEY_INFO"
    
    # Check signature algorithm
    echo -e "\n${BLUE}Signature Algorithm:${NC}"
    SIG_ALG=$(openssl x509 -in "$OUTPUT_DIR/certificate.pem" -noout -text | grep "Signature Algorithm" | head -1)
    echo "$SIG_ALG"
    
    # Check for weak algorithms
    if echo "$SIG_ALG" | grep -qi "md5\|sha1"; then
        echo -e "${RED}⚠ WARNING: Weak signature algorithm detected!${NC}"
    else
        echo -e "${GREEN}✓ Strong signature algorithm${NC}"
    fi
    
    # Check certificate validity
    echo -e "\n${BLUE}Certificate Validity Check:${NC}"
    if openssl x509 -in "$OUTPUT_DIR/certificate.pem" -noout -checkend 0 >/dev/null 2>&1; then
        echo -e "${GREEN}✓ Certificate is currently valid${NC}"
    else
        echo -e "${RED}✗ Certificate has expired or is not yet valid${NC}"
    fi
    
    # Check expiration warning (30 days)
    if openssl x509 -in "$OUTPUT_DIR/certificate.pem" -noout -checkend 2592000 >/dev/null 2>&1; then
        echo -e "${GREEN}✓ Certificate valid for more than 30 days${NC}"
    else
        echo -e "${YELLOW}⚠ Certificate expires within 30 days${NC}"
    fi
}

# Function to generate summary report
generate_summary() {
    echo -e "\n${YELLOW}=== Analysis Summary ===${NC}"
    
    SUMMARY_FILE="$OUTPUT_DIR/analysis_summary.txt"
    
    cat > "$SUMMARY_FILE" << EOF
CS4910 Lab 1 - Certificate Analysis Summary
==========================================
Domain Analyzed: $DOMAIN
Analysis Date: $(date)
Analysis Tool: OpenSSL $(openssl version | cut -d' ' -f2)

Key Findings:
EOF
    
    if [ -f "$OUTPUT_DIR/subject.txt" ]; then
        echo "- Subject: $(cat "$OUTPUT_DIR/subject.txt")" >> "$SUMMARY_FILE"
    fi
    
    if [ -f "$OUTPUT_DIR/issuer.txt" ]; then
        echo "- Issuer: $(cat "$OUTPUT_DIR/issuer.txt")" >> "$SUMMARY_FILE"
    fi
    
    if [ -f "$OUTPUT_DIR/sha1_fingerprint.txt" ]; then
        echo "- SHA-1 Fingerprint: $(cat "$OUTPUT_DIR/sha1_fingerprint.txt")" >> "$SUMMARY_FILE"
    fi
    
    if [ -f "$OUTPUT_DIR/validity_dates.txt" ]; then
        echo "- Validity: $(cat "$OUTPUT_DIR/validity_dates.txt")" >> "$SUMMARY_FILE"
    fi
    
    echo "" >> "$SUMMARY_FILE"
    echo "Files Generated:" >> "$SUMMARY_FILE"
    ls -la "$OUTPUT_DIR"/ >> "$SUMMARY_FILE"
    
    echo -e "${GREEN}✓ Summary report generated: $SUMMARY_FILE${NC}"
    
    # Display summary
    cat "$SUMMARY_FILE"
}

# Function to provide educational information
educational_info() {
    echo -e "\n${YELLOW}=== Educational Information ===${NC}"
    
    cat << EOF
${BLUE}What is a Digital Certificate?${NC}
A digital certificate is an electronic document that uses a digital signature 
to bind a public key with an identity (person, organization, server, etc.).

${BLUE}Purpose of Digital Certificates:${NC}
1. Authentication - Verify the identity of the certificate holder
2. Encryption - Enable secure communication using public key cryptography
3. Integrity - Ensure data hasn't been tampered with during transmission
4. Non-repudiation - Provide proof of origin and delivery

${BLUE}Certificate Authority (CA) Role:${NC}
- Trusted third party that issues and manages digital certificates
- Validates the identity of certificate requesters
- Signs certificates with their private key
- Maintains certificate revocation lists (CRLs)

${BLUE}Certificate Chain of Trust:${NC}
Root CA → Intermediate CA → End-Entity Certificate
Each level signs the certificate below it, creating a chain of trust.

${BLUE}Common Certificate Fields:${NC}
- Subject: Who the certificate belongs to
- Issuer: Who issued the certificate (CA)
- Validity Period: When the certificate is valid (Not Before/Not After)
- Public Key: The public key associated with the certificate
- Signature: Digital signature from the issuing CA
- Serial Number: Unique identifier for the certificate

${BLUE}Fingerprints:${NC}
Hash values of the certificate that provide a unique identifier.
Used to verify certificate authenticity and detect tampering.
EOF
}

# Function to show student assignment questions
show_assignment_questions() {
    echo -e "\n${YELLOW}=== Student Assignment Questions ===${NC}"
    
    cat << EOF
Based on your certificate analysis, answer these questions:

${BLUE}a) Objective of Digital Certificate:${NC}
   What is the main purpose of the digital certificate you analyzed?

${BLUE}b) SHA-1 Fingerprint and CA:${NC}
   - What is the SHA-1 fingerprint of the certificate?
   - Which Certificate Authority issued this certificate?
   - Who is the subject (owner) of the certificate?

${BLUE}c) Certificate Generation Date:${NC}
   - When was this certificate issued (Not Before date)?
   - When does it expire (Not After date)?
   - Does the website need to present this certificate every time a client accesses it?

${BLUE}d) Methodology:${NC}
   - Explain the tools and commands you used for this analysis
   - What steps did you follow to extract the certificate information?
   - How could someone else reproduce your analysis?

${BLUE}Additional Analysis:${NC}
   - Is the certificate currently valid?
   - What signature algorithm is used?
   - What is the key size and algorithm?
   - Are there any security concerns with this certificate?

All output files have been saved to the '$OUTPUT_DIR' directory for your reference.
EOF
}

# Main execution
main() {
    check_openssl
    
    if get_certificate; then
        show_certificate_details
        extract_key_info
        show_fingerprints
        show_certificate_chain
        security_analysis
        generate_summary
        educational_info
        show_assignment_questions
        
        echo -e "\n${GREEN}================================================================${NC}"
        echo -e "${GREEN}Certificate analysis complete!${NC}"
        echo -e "${GREEN}All output files saved to: $OUTPUT_DIR/${NC}"
        echo -e "${GREEN}================================================================${NC}"
    else
        echo -e "\n${RED}Certificate analysis failed. Please check the domain name and try again.${NC}"
        exit 1
    fi
}

# Run main function
main "$@"