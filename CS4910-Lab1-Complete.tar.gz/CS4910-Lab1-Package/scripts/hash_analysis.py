#!/usr/bin/env python3
"""
CS4910 Lab 1 - Hash Function Analysis Tool
University of Colorado Colorado Springs
Fall 2025 - Instructor: Rhett Saunders

This script demonstrates hash function properties and collision resistance concepts.
"""

import hashlib
import random
import string
import time
import math
from collections import defaultdict
import json

class HashAnalyzer:
    def __init__(self):
        self.algorithms = ['md5', 'sha1', 'sha256', 'sha512']
        self.results = {}
    
    def hash_string(self, data, algorithm='sha256'):
        """Hash a string using specified algorithm"""
        try:
            hasher = hashlib.new(algorithm)
            hasher.update(data.encode('utf-8'))
            return hasher.hexdigest()
        except ValueError:
            print(f"Algorithm {algorithm} not available")
            return None
    
    def demonstrate_avalanche_effect(self, base_string="CS4910 Security Lab"):
        """Demonstrate how small changes dramatically affect hash output"""
        print(f"\n{'='*60}")
        print("AVALANCHE EFFECT DEMONSTRATION")
        print(f"{'='*60}")
        print(f"Base string: '{base_string}'")
        
        base_hash = self.hash_string(base_string)
        print(f"SHA256 Hash: {base_hash}")
        
        # Various small modifications
        modifications = [
            (base_string + "!", "Add exclamation mark"),
            (base_string.replace("C", "c"), "Change first letter to lowercase"),
            (base_string.replace(" ", "_"), "Replace space with underscore"),
            (base_string[:-1], "Remove last character"),
            (base_string + " ", "Add trailing space"),
            (base_string.replace("Security", "security"), "Change case of 'Security'")
        ]
        
        avalanche_results = []
        
        for i, (modified, description) in enumerate(modifications):
            mod_hash = self.hash_string(modified)
            print(f"\n--- Modification {i+1}: {description} ---")
            print(f"Modified string: '{modified}'")
            print(f"SHA256 Hash: {mod_hash}")
            
            # Calculate bit differences (Hamming distance)
            diff_bits = self._calculate_hamming_distance(base_hash, mod_hash)
            total_bits = len(base_hash) * 4  # Each hex digit = 4 bits
            diff_percentage = (diff_bits / total_bits) * 100
            
            print(f"Bit differences: {diff_bits}/{total_bits} ({diff_percentage:.1f}%)")
            
            avalanche_results.append({
                'modification': description,
                'original': base_string,
                'modified': modified,
                'bit_differences': diff_bits,
                'percentage': diff_percentage
            })
        
        # Calculate average avalanche effect
        avg_percentage = sum(r['percentage'] for r in avalanche_results) / len(avalanche_results)
        print(f"\nAverage bit change: {avg_percentage:.1f}%")
        print("Good hash functions should change ~50% of bits for small input changes")
        
        self.results['avalanche_effect'] = {
            'base_string': base_string,
            'modifications': avalanche_results,
            'average_change_percentage': avg_percentage
        }
        
        return avalanche_results
    
    def _calculate_hamming_distance(self, hash1, hash2):
        """Calculate Hamming distance between two hex strings"""
        if len(hash1) != len(hash2):
            return -1
        
        # Convert hex to binary and count differing bits
        diff_bits = 0
        for c1, c2 in zip(hash1, hash2):
            # XOR the hex digits and count set bits
            xor_result = int(c1, 16) ^ int(c2, 16)
            diff_bits += bin(xor_result).count('1')
        
        return diff_bits
    
    def birthday_attack_simulation(self, hash_bits=16, max_attempts=100000):
        """Simulate birthday attack on truncated hash"""
        print(f"\n{'='*60}")
        print("BIRTHDAY ATTACK SIMULATION")
        print(f"{'='*60}")
        print(f"Using {hash_bits}-bit truncated SHA256")
        print(f"Theoretical collision probability: ~50% after {2**(hash_bits/2):.0f} attempts")
        
        hash_map = {}
        attempts = 0
        start_time = time.time()
        
        while attempts < max_attempts:
            # Generate random string
            random_string = ''.join(random.choices(string.ascii_letters + string.digits, k=12))
            
            # Get truncated hash
            full_hash = self.hash_string(random_string)
            if not full_hash:
                continue
                
            # Truncate to specified bit length (convert bits to hex characters)
            hex_chars = hash_bits // 4
            truncated_hash = full_hash[:hex_chars]
            
            if truncated_hash in hash_map:
                end_time = time.time()
                collision_data = {
                    'attempts': attempts,
                    'time_seconds': end_time - start_time,
                    'string1': hash_map[truncated_hash],
                    'string2': random_string,
                    'collision_hash': truncated_hash,
                    'theoretical_attempts': 2**(hash_bits/2),
                    'hash_bits': hash_bits
                }
                
                print(f"\n🎯 COLLISION FOUND!")
                print(f"Attempts: {attempts}")
                print(f"Time: {collision_data['time_seconds']:.2f} seconds")
                print(f"String 1: '{collision_data['string1']}'")
                print(f"String 2: '{collision_data['string2']}'")
                print(f"Collision hash: {truncated_hash}")
                print(f"Theoretical expectation: ~{collision_data['theoretical_attempts']:.0f} attempts")
                print(f"Actual vs Theoretical: {(attempts/collision_data['theoretical_attempts']*100):.1f}%")
                
                self.results['birthday_attack'] = collision_data
                return collision_data
            
            hash_map[truncated_hash] = random_string
            attempts += 1
            
            # Progress indicator
            if attempts % 5000 == 0:
                print(f"Attempts: {attempts} (no collision yet)")
        
        print(f"\nNo collision found after {attempts} attempts")
        print("Try increasing max_attempts or reducing hash_bits")
        
        return None
    
    def compare_algorithms(self, test_string="CS4910 Hash Function Analysis"):
        """Compare different hash algorithms"""
        print(f"\n{'='*60}")
        print("HASH ALGORITHM COMPARISON")
        print(f"{'='*60}")
        print(f"Input: '{test_string}'")
        
        algorithm_results = {}
        
        for algo in self.algorithms:
            hash_value = self.hash_string(test_string, algo)
            if hash_value:
                bit_length = len(hash_value) * 4  # hex chars to bits
                print(f"\n{algo.upper()}:")
                print(f"  Hash: {hash_value}")
                print(f"  Length: {len(hash_value)} hex chars ({bit_length} bits)")
                
                algorithm_results[algo] = {
                    'hash': hash_value,
                    'hex_length': len(hash_value),
                    'bit_length': bit_length
                }
            else:
                print(f"{algo.upper()}: Not available")
        
        self.results['algorithm_comparison'] = {
            'input': test_string,
            'algorithms': algorithm_results
        }
        
        return algorithm_results
    
    def collision_resistance_explanation(self):
        """Explain collision resistance concepts"""
        print(f"\n{'='*60}")
        print("COLLISION RESISTANCE CONCEPTS")
        print(f"{'='*60}")
        
        print("1. WEAK COLLISION RESISTANCE (Second Preimage Resistance):")
        print("   Given a message x, it's computationally infeasible to find")
        print("   another message x' ≠ x such that H(x) = H(x')")
        print("   Example: Given Alice's message, hard to find different message")
        print("           with same hash (like forging Alice's signature)")
        
        print("\n2. STRONG COLLISION RESISTANCE:")
        print("   It's computationally infeasible to find any two messages")
        print("   x and x' where x ≠ x' such that H(x) = H(x')")
        print("   Example: Hard to find ANY two different messages with same hash")
        
        print("\n3. BIRTHDAY PARADOX ANALOGY:")
        print("   • Finding someone with Alice's birthday (Jan 1): 1/365 chance")
        print("     → Requires checking ~183 people on average")
        print("   • Finding ANY two people with same birthday: 50% chance with")
        print("     just 23 people → Much easier!")
        print("   • This is why strong collision resistance is harder to achieve")
        
        print("\n4. HASH FUNCTION IMPLICATIONS:")
        print("   • Weak collision resistance ≈ finding specific birthday match")
        print("   • Strong collision resistance ≈ finding any birthday match")
        print("   • Birthday attack exploits this mathematical principle")
        print("   • For n-bit hash: ~2^n attempts for weak, ~2^(n/2) for strong")
    
    def pigeonhole_principle_demo(self):
        """Demonstrate pigeonhole principle with hash functions"""
        print(f"\n{'='*60}")
        print("PIGEONHOLE PRINCIPLE DEMONSTRATION")
        print(f"{'='*60}")
        
        print("Question: For hash function H(m), if x ≠ x', is H(x) ≠ H(x') always true?")
        print("\nAnswer: NO! Here's why:")
        print("\n1. PIGEONHOLE PRINCIPLE:")
        print("   • If you have more pigeons than pigeonholes, at least one")
        print("     pigeonhole must contain more than one pigeon")
        
        print("\n2. HASH FUNCTION APPLICATION:")
        print("   • Input space: Infinite possible messages")
        print("   • Output space: Fixed size (e.g., 256 bits for SHA-256)")
        print("   • 2^256 possible hash values vs infinite inputs")
        print("   • Therefore, collisions MUST exist mathematically")
        
        print("\n3. PRACTICAL EXAMPLE:")
        # Demonstrate with very small hash space
        small_hash_bits = 8
        print(f"   Using {small_hash_bits}-bit hash space ({2**small_hash_bits} possible values):")
        
        seen_hashes = set()
        collision_found = False
        
        for i in range(300):  # Try 300 inputs
            test_input = f"message_{i}"
            full_hash = self.hash_string(test_input)
            if full_hash:
                # Truncate to small_hash_bits
                truncated = full_hash[:small_hash_bits//4]
                
                if truncated in seen_hashes and not collision_found:
                    print(f"   Collision found at input #{i}: hash = {truncated}")
                    collision_found = True
                    break
                
                seen_hashes.add(truncated)
        
        print(f"\n4. CONCLUSION:")
        print("   Collisions are mathematically guaranteed to exist!")
        print("   The security comes from making them computationally hard to find.")
    
    def generate_comprehensive_report(self):
        """Generate a comprehensive analysis report"""
        print(f"\n{'='*80}")
        print("COMPREHENSIVE HASH FUNCTION ANALYSIS REPORT")
        print(f"{'='*80}")
        print(f"Generated: {time.strftime('%Y-%m-%d %H:%M:%S')}")
        print("CS4910 Lab 1 - University of Colorado Colorado Springs")
        
        if 'avalanche_effect' in self.results:
            print(f"\n1. AVALANCHE EFFECT ANALYSIS:")
            avg_change = self.results['avalanche_effect']['average_change_percentage']
            print(f"   Average bit change: {avg_change:.1f}%")
            if avg_change > 40:
                print("   ✓ Good avalanche effect (>40% bit change)")
            else:
                print("   ⚠ Poor avalanche effect (<40% bit change)")
        
        if 'birthday_attack' in self.results:
            print(f"\n2. BIRTHDAY ATTACK SIMULATION:")
            ba_data = self.results['birthday_attack']
            efficiency = (ba_data['attempts'] / ba_data['theoretical_attempts']) * 100
            print(f"   Collision found in {ba_data['attempts']} attempts")
            print(f"   Efficiency: {efficiency:.1f}% of theoretical expectation")
        
        if 'algorithm_comparison' in self.results:
            print(f"\n3. ALGORITHM COMPARISON:")
            for algo, data in self.results['algorithm_comparison']['algorithms'].items():
                print(f"   {algo.upper()}: {data['bit_length']} bits")
    
    def save_results(self, filename="hash_analysis_results.json"):
        """Save all analysis results to JSON file"""
        try:
            with open(filename, 'w') as f:
                json.dump(self.results, f, indent=2)
            print(f"\nResults saved to: {filename}")
        except Exception as e:
            print(f"Error saving results: {e}")

def main():
    """Main function demonstrating hash function analysis"""
    analyzer = HashAnalyzer()
    
    print("CS4910 Lab 1 - Hash Function Analysis Tool")
    print("University of Colorado Colorado Springs")
    print("Fall 2025 - Instructor: Rhett Saunders")
    
    # Run all demonstrations
    analyzer.demonstrate_avalanche_effect()
    analyzer.compare_algorithms()
    analyzer.collision_resistance_explanation()
    analyzer.pigeonhole_principle_demo()
    analyzer.birthday_attack_simulation(16)  # 16-bit for reasonable demo time
    
    # Generate comprehensive report
    analyzer.generate_comprehensive_report()
    analyzer.save_results()
    
    print(f"\n{'='*60}")
    print("STUDENT ASSIGNMENT QUESTIONS")
    print(f"{'='*60}")
    print("Answer these questions based on the analysis above:")
    print("\n1. Is H(x) ≠ H(x') always true for x ≠ x'? Explain using pigeonhole principle.")
    print("2. Define weak vs strong collision resistance and explain differences.")
    print("3. Explain birthday paradox and its application to hash attacks.")
    print("4. Compare finding Alice's specific birthday vs any matching birthdays.")
    print("5. Relate this to weak vs strong collision resistance.")

if __name__ == "__main__":
    main()